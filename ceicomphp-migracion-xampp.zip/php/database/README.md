# Preparar la base de Ceicom en XAMPP

Estos pasos crean la base MySQL o MariaDB y copian los datos desde una restauración local de PostgreSQL. El código Node.js original sigue siendo el punto de entrada de la aplicación en este checkout. La interfaz web en PHP está pendiente.

## Crear la base

1. Instala XAMPP con PHP 8.2 o posterior. Inicia **MySQL** desde su panel. XAMPP suele distribuir MariaDB bajo ese nombre. El esquema se probó con MariaDB 10.4.
2. Comprueba que el PHP de XAMPP tenga los controladores:

   ```powershell
   & C:\xampp\php\php.exe -m | Select-String 'pdo_mysql|pdo_pgsql'
   ```

   Si falta uno, habilita `extension=pdo_mysql` o `extension=pdo_pgsql` en `C:\xampp\php\php.ini` y vuelve a comprobarlo. `pdo_pgsql` se usa durante la migración.
3. Desde PowerShell, abre la carpeta del repositorio y crea una base vacía:

   ```powershell
   & C:\xampp\mysql\bin\mysql.exe -u root -p -e "CREATE DATABASE ceicomphp CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;"
   ```

   Si tu instalación local tiene la cuenta `root` sin contraseña, omite `-p`. Selecciona `ceicomphp` en phpMyAdmin e importa `php/database/schema.sql`. También puedes usar una cuenta local dedicada con permisos para crear el esquema e importar filas. Guarda el repositorio y los archivos privados fuera de `C:\xampp\htdocs`.
4. Si tienes planes de estudio de hasta 20 MB, configura `max_allowed_packet=64M` en la sección `[mysqld]` de `C:\xampp\mysql\bin\my.ini` y reinicia MySQL antes de copiar los datos.

## Restaurar el respaldo de PostgreSQL

Usa las herramientas PostgreSQL de la misma versión mayor que generó el respaldo, o una compatible más reciente. Agrega su directorio `bin` al PATH de la terminal o utiliza las rutas completas. Trabaja con una **base temporal nueva** y deja intacta la base en uso.

```powershell
createdb -h 127.0.0.1 -U postgres ceicom_migracion
pg_restore -h 127.0.0.1 -U postgres --no-owner --no-privileges --exit-on-error -d ceicom_migracion "C:\privado\ceicom.dump"
```

Para un respaldo que sea texto SQL, restaura en la base temporal recién creada mediante `psql`:

```powershell
psql -h 127.0.0.1 -U postgres -v ON_ERROR_STOP=1 -d ceicom_migracion -f "C:\privado\ceicom.sql"
```

Si tienes acceso directo al PostgreSQL original y todavía no tienes un dump, puedes generar uno con `pg_dump -Fc`. Si el respaldo precede a la migración `010_career_names.sql`, aplica las migraciones del proyecto Node.js a la **copia restaurada** antes de importar. Desde el repositorio ejecuta `npm ci` y luego `npm run db:migrate` con `DATABASE_URL` apuntando a `ceicom_migracion`.

## Copiar los datos

1. Copia `php/database/config.example.php` a `php/database/config.local.php` y edita los usuarios, contraseñas, puertos y nombres de base. Si MySQL de XAMPP usa otro puerto, cambia el DSN. Puedes guardar el archivo en una carpeta privada y pasar su ruta como argumento.
2. Mantén libre la base de destino durante la copia y ejecuta:

   ```powershell
   & C:\xampp\php\php.exe .\php\database\import-postgres.php
   ```

3. Comprueba que el programa termine con **Importación confirmada** y guarda los recuentos de control. Revisa una carrera con nombre por gestión, una inscripción con sus notas y un PDF de plan de estudios en la copia. Luego puedes apagar el servidor PostgreSQL temporal.

La herramienta preserva identificadores, relaciones, datos académicos, documentos y los hashes de las contraseñas. La aplicación PHP deberá implementar la verificación del formato scrypt del sistema original para que las cuentas migradas puedan iniciar sesión con sus claves. Las sesiones activas se descartan. Si una fila falla, se revierten las inserciones y el programa indica la tabla. La importación solo acepta un destino vacío, de modo que una segunda ejecución sobre una copia ya importada se rechaza.

El dump puede contener documentos, notas y hashes de contraseñas. Guárdalo fuera del repositorio y de la carpeta web. Para compartir un caso de prueba, crea una copia anonimizada que mantenga los IDs y las relaciones entre tablas.

## Respaldar la copia local

En PowerShell, genera un respaldo de la base migrada con las herramientas de XAMPP. La opción `--hex-blob` conserva los documentos binarios. Usa una carpeta privada existente para el archivo.

```powershell
& C:\xampp\mysql\bin\mysqldump.exe -u root -p --single-transaction --hex-blob --skip-add-drop-table --result-file=C:\privado\ceicomphp.sql ceicomphp
```

Para comprobar un respaldo, crea una base vacía con el mismo juego de caracteres e importa el archivo en esa base desde phpMyAdmin. Verifica el destino seleccionado antes de importar.
