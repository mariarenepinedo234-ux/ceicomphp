SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ci VARCHAR(255) UNIQUE,
  name TEXT NOT NULL,
  role VARCHAR(16) NOT NULL CHECK (role IN ('admin','teacher','student')),
  password TEXT,
  must_change INT NOT NULL DEFAULT 1,
  blocked INT NOT NULL DEFAULT 0,
  CHECK ((role IN ('student','teacher') AND ci IS NULL AND password IS NULL)
         OR (ci IS NOT NULL AND password IS NOT NULL))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE careers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE shifts LIKE careers;
CREATE TABLE years LIKE careers;

CREATE TABLE career_names (
  career_id INT NOT NULL,
  year_id INT NOT NULL,
  name VARCHAR(160) NOT NULL CHECK (CHAR_LENGTH(TRIM(name)) BETWEEN 1 AND 160),
  PRIMARY KEY (career_id, year_id),
  FOREIGN KEY (career_id) REFERENCES careers(id) ON DELETE CASCADE,
  FOREIGN KEY (year_id) REFERENCES years(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE subjects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name TEXT NOT NULL,
  career_id INT NOT NULL,
  level INT NOT NULL CHECK (level BETWEEN 1 AND 3),
  code VARCHAR(255),
  active BOOLEAN NOT NULL DEFAULT TRUE,
  catalog_order INT CHECK (catalog_order > 0),
  code_key VARCHAR(255) GENERATED ALWAYS AS (UPPER(code)) STORED,
  UNIQUE (career_id, level, code_key),
  FOREIGN KEY (career_id) REFERENCES careers(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE modules (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  year_id INT NOT NULL,
  admission_year_id INT,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  calendar_key INT GENERATED ALWAYS AS (COALESCE(admission_year_id,0)) STORED,
  CHECK (start_date <= end_date),
  UNIQUE (year_id, calendar_key, name),
  INDEX (year_id, admission_year_id, start_date, end_date),
  FOREIGN KEY (year_id) REFERENCES years(id),
  FOREIGN KEY (admission_year_id) REFERENCES years(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE students (
  user_id INT PRIMARY KEY,
  career_id INT NOT NULL,
  shift_id INT NOT NULL,
  admission_year_id INT NOT NULL,
  level INT NOT NULL CHECK (level BETWEEN 1 AND 3),
  name_pending BOOLEAN NOT NULL DEFAULT FALSE,
  INDEX (career_id, shift_id),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (career_id) REFERENCES careers(id),
  FOREIGN KEY (shift_id) REFERENCES shifts(id),
  FOREIGN KEY (admission_year_id) REFERENCES years(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE subject_series (
  id INT AUTO_INCREMENT PRIMARY KEY,
  subject_id INT NOT NULL,
  shift_id INT NOT NULL,
  part_count INT NOT NULL CHECK (part_count >= 2),
  completed BOOLEAN NOT NULL DEFAULT FALSE,
  UNIQUE (id, subject_id, shift_id),
  FOREIGN KEY (subject_id) REFERENCES subjects(id),
  FOREIGN KEY (shift_id) REFERENCES shifts(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE offerings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  subject_id INT NOT NULL,
  module_id INT NOT NULL,
  shift_id INT NOT NULL,
  teacher_id INT NOT NULL,
  unlocked_until DATETIME(6),
  series_id INT,
  part_number INT,
  part_recovery BOOLEAN NOT NULL DEFAULT FALSE,
  original_part INT GENERATED ALWAYS AS (CASE WHEN NOT part_recovery THEN part_number END) STORED,
  UNIQUE (subject_id, module_id, shift_id),
  UNIQUE (series_id, original_part),
  INDEX (teacher_id, module_id),
  INDEX (series_id, part_number),
  CHECK ((series_id IS NULL AND part_number IS NULL AND NOT part_recovery)
      OR (series_id IS NOT NULL AND part_number IS NOT NULL AND part_number >= 1)),
  FOREIGN KEY (series_id, subject_id, shift_id) REFERENCES subject_series(id, subject_id, shift_id),
  FOREIGN KEY (subject_id) REFERENCES subjects(id),
  FOREIGN KEY (module_id) REFERENCES modules(id),
  FOREIGN KEY (shift_id) REFERENCES shifts(id),
  FOREIGN KEY (teacher_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE enrollments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  offering_id INT NOT NULL,
  grade DOUBLE CHECK (grade BETWEEN 1 AND 100),
  updated_at DATETIME(6),
  saber DOUBLE CHECK (saber BETWEEN 0 AND 100),
  hacer DOUBLE CHECK (hacer BETWEEN 0 AND 100),
  ser DOUBLE CHECK (ser BETWEEN 0 AND 100),
  is_retake BOOLEAN NOT NULL DEFAULT FALSE,
  UNIQUE (student_id, offering_id),
  INDEX (offering_id, student_id),
  FOREIGN KEY (student_id) REFERENCES students(user_id),
  FOREIGN KEY (offering_id) REFERENCES offerings(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE audit (
  id INT AUTO_INCREMENT PRIMARY KEY,
  actor_id INT,
  action TEXT NOT NULL,
  detail TEXT NOT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  FOREIGN KEY (actor_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE sessions (
  token VARCHAR(255) PRIMARY KEY,
  user_id INT NOT NULL,
  expires BIGINT NOT NULL,
  INDEX (expires),
  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE teacher_directory (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name TEXT NOT NULL,
  name_key VARCHAR(255) NOT NULL UNIQUE,
  user_id INT UNIQUE,
  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE catalog_import_batches (
  token VARCHAR(255) PRIMARY KEY,
  actor_id INT NOT NULL,
  payload JSON NOT NULL,
  expires_at DATETIME(6) NOT NULL,
  applied_at DATETIME(6),
  INDEX (expires_at),
  FOREIGN KEY (actor_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE academic_groups (
  id INT AUTO_INCREMENT PRIMARY KEY,
  subject_id INT NOT NULL,
  year_id INT NOT NULL,
  admission_year_id INT NOT NULL,
  shift_id INT NOT NULL,
  offering_id INT UNIQUE,
  pending_key INT GENERATED ALWAYS AS (CASE WHEN offering_id IS NULL THEN 1 END) STORED,
  UNIQUE (subject_id, year_id, admission_year_id, shift_id, pending_key),
  FOREIGN KEY (subject_id) REFERENCES subjects(id),
  FOREIGN KEY (year_id) REFERENCES years(id),
  FOREIGN KEY (admission_year_id) REFERENCES years(id),
  FOREIGN KEY (shift_id) REFERENCES shifts(id),
  FOREIGN KEY (offering_id) REFERENCES offerings(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE academic_group_students (
  group_id INT NOT NULL,
  student_id INT NOT NULL,
  PRIMARY KEY (group_id, student_id),
  FOREIGN KEY (group_id) REFERENCES academic_groups(id),
  FOREIGN KEY (student_id) REFERENCES students(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE study_plans (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(160) NOT NULL CHECK (CHAR_LENGTH(title) BETWEEN 1 AND 160),
  career_id INT NOT NULL,
  level INT NOT NULL CHECK (level BETWEEN 1 AND 3),
  original_name VARCHAR(200) NOT NULL CHECK (CHAR_LENGTH(original_name) BETWEEN 1 AND 200),
  content LONGBLOB NOT NULL,
  size_bytes INT NOT NULL CHECK (size_bytes BETWEEN 16 AND 20971520),
  uploaded_by INT NOT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  CHECK (OCTET_LENGTH(content) = size_bytes),
  INDEX (career_id, level, created_at),
  FOREIGN KEY (career_id) REFERENCES careers(id),
  FOREIGN KEY (uploaded_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
