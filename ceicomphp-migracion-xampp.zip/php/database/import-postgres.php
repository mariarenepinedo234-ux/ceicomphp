<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

const TABLE_COLUMNS = [
    'users' => 'id ci name role password must_change blocked',
    'careers' => 'id name',
    'shifts' => 'id name',
    'years' => 'id name',
    'career_names' => 'career_id year_id name',
    'subjects' => 'id name career_id level code active catalog_order',
    'modules' => 'id name year_id admission_year_id start_date end_date',
    'students' => 'user_id career_id shift_id admission_year_id level name_pending',
    'subject_series' => 'id subject_id shift_id part_count completed',
    'offerings' => 'id subject_id module_id shift_id teacher_id unlocked_until series_id part_number part_recovery',
    'enrollments' => 'id student_id offering_id grade updated_at saber hacer ser is_retake',
    'audit' => 'id actor_id action detail created_at',
    'teacher_directory' => 'id name name_key user_id',
    'catalog_import_batches' => 'token actor_id payload expires_at applied_at',
    'academic_groups' => 'id subject_id year_id admission_year_id shift_id offering_id',
    'academic_group_students' => 'group_id student_id',
    'study_plans' => 'id title career_id level original_name content size_bytes uploaded_by created_at',
];

function connect(array $config, string $driver): PDO
{
    if (!str_starts_with($config['dsn'], $driver . ':')) {
        throw new InvalidArgumentException('El DSN debe usar ' . $driver . '.');
    }

    return new PDO($config['dsn'], $config['user'], $config['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
}

function copyTable(PDO $source, PDO $destination, string $table, array $columns): int
{
    $sourceColumns = array_map(
        static fn (string $column): string => match ($column) {
            'content' => "encode(content, 'hex')",
            'unlocked_until', 'updated_at', 'created_at', 'expires_at', 'applied_at'
                => "to_char(\"$column\", 'YYYY-MM-DD HH24:MI:SS.US')",
            default => '"' . $column . '"',
        },
        $columns,
    );
    $destinationColumns = implode(', ', array_map(static fn ($column) => "`$column`", $columns));
    $placeholders = implode(', ', array_fill(0, count($columns), '?'));
    $insert = $destination->prepare("INSERT INTO `$table` ($destinationColumns) VALUES ($placeholders)");
    $source->exec('DECLARE migration_rows NO SCROLL CURSOR FOR SELECT '
        . implode(', ', $sourceColumns) . " FROM public.\"$table\"");
    $count = 0;

    do {
        $rows = $source->query('FETCH FORWARD ' . ($table === 'study_plans' ? 1 : 200) . ' FROM migration_rows');
        foreach ($rows->fetchAll(PDO::FETCH_NUM) as $row) {
            foreach ($row as $index => $value) {
                if ($columns[$index] === 'content') {
                    $binary = hex2bin($value);
                    if ($binary === false) {
                        throw new RuntimeException('Un PDF del origen no pudo convertirse a binario.');
                    }
                    $insert->bindValue($index + 1, $binary, PDO::PARAM_LOB);
                } elseif ($value === null) {
                    $insert->bindValue($index + 1, null, PDO::PARAM_NULL);
                } elseif (is_bool($value) || is_int($value)) {
                    $insert->bindValue($index + 1, (int) $value, PDO::PARAM_INT);
                } else {
                    $insert->bindValue($index + 1, (string) $value, PDO::PARAM_STR);
                }
            }

            $insert->execute();
            $count++;
        }
        $hasRows = $rows->rowCount() > 0;
        $rows->closeCursor();
    } while ($hasRows);

    $source->exec('CLOSE migration_rows');
    $sourceCount = (int) $source->query("SELECT COUNT(*) FROM public.\"$table\"")->fetchColumn();
    $destinationCount = (int) $destination->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
    if ($count !== $sourceCount || $count !== $destinationCount) {
        throw new RuntimeException("El recuento de $table no coincide.");
    }
    return $count;
}

$configFile = $argv[1] ?? __DIR__ . '/config.local.php';
if (!is_file($configFile)) {
    fwrite(STDERR, "Copia config.example.php a config.local.php y configura las conexiones locales.\n");
    exit(1);
}

$stage = 'conexiones';
try {
    $config = require $configFile;
    $source = connect($config['postgres'], 'pgsql');
    $destination = connect($config['mysql'], 'mysql');

    $stage = 'preparación';
    $destination->exec("SET time_zone = '+00:00'");
    $destination->exec("SET SESSION sql_mode = 'STRICT_ALL_TABLES,NO_AUTO_VALUE_ON_ZERO,NO_ENGINE_SUBSTITUTION'");
    $destination->exec('SET SESSION foreign_key_checks = 1, unique_checks = 1');
    $lock = $destination->query("SELECT GET_LOCK(CONCAT('ceicom-import:', SHA2(DATABASE(),224)),0)")
        ->fetchColumn();
    if ((int) $lock !== 1) {
        throw new RuntimeException('Ya existe una importación en ejecución.');
    }
    $destination->beginTransaction();
    $source->beginTransaction();
    $source->exec('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY');
    $source->exec("SET LOCAL TIME ZONE 'UTC'");

    foreach ([...array_keys(TABLE_COLUMNS), 'sessions'] as $table) {
        if ((int) $destination->query("SELECT COUNT(*) FROM `$table`")->fetchColumn() !== 0) {
            throw new RuntimeException("La base de destino contiene registros en $table.");
        }
    }

    $counts = [];
    foreach (TABLE_COLUMNS as $table => $columnNames) {
        $stage = "tabla $table";
        $counts[$table] = copyTable($source, $destination, $table, explode(' ', $columnNames));
    }

    $stage = 'confirmación';
    $source->commit();
    $destination->commit();
    foreach ($counts as $table => $count) {
        printf("%s: %d\n", $table, $count);
    }
    fwrite(STDOUT, "Importación confirmada. Las sesiones anteriores quedan fuera de la copia.\n");
} catch (Throwable $error) {
    if (isset($destination) && $destination->inTransaction()) {
        $destination->rollBack();
    }
    if (isset($source) && $source->inTransaction()) {
        $source->rollBack();
    }
    // Los errores de PDO pueden incluir valores privados de las filas o de la conexión.
    $reason = $error instanceof PDOException ? 'SQLSTATE ' . $error->getCode() : $error->getMessage();
    fwrite(STDERR, "Importación interrumpida durante $stage ($reason).\n");
    exit(1);
}
