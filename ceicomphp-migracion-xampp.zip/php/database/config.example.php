<?php

return [
    'postgres' => [
        'dsn' => 'pgsql:host=127.0.0.1;port=5432;dbname=ceicom_migracion',
        'user' => 'postgres',
        'password' => '',
    ],
    'mysql' => [
        'dsn' => 'mysql:host=127.0.0.1;port=3306;dbname=ceicomphp;charset=utf8mb4',
        'user' => 'root',
        'password' => '',
    ],
];
