# Portal Ceicom para pruebas locales con XAMPP

El portal usa PHP y MySQL/MariaDB con la interfaz de Ceicom. El ZIP incluye las dependencias PHP.

1. Usa XAMPP con PHP 8.2 o posterior. En `php.ini`, comprueba que estén habilitadas
   las extensiones `pdo_mysql`, `mbstring`, `sodium`, `gd`, `zip` y las extensiones XML que incluye XAMPP. Habilita
   `pdo_pgsql` si vas a importar el respaldo de PostgreSQL.
2. Extrae la carpeta `ceicomphp` del ZIP en `C:\xampp\htdocs\`. En el panel
   de XAMPP, inicia Apache y MySQL. Apache debe tener `mod_rewrite` activo y
   permitir las directivas de `.htaccess` en `htdocs` (`AllowOverride All`).
3. En phpMyAdmin, crea la base `ceicomphp` con cotejamiento `utf8mb4_bin`.
   Selecciona esa base e importa `database/schema.sql` y luego
   `database/web-schema.sql`. Si ya preparaste el esquema del kit de migración,
   aplica únicamente `database/web-schema.sql`.
4. Para conservar las cuentas y registros de tu respaldo, sigue la guía
   `database/README.md` y ejecuta el importador desde una carpeta privada.
   El respaldo de Ceicom que probamos se generó con PostgreSQL 18. El destino
   de la migración debe estar vacío.
5. Copia `app/config.example.php` a `app/config.local.php` y configura el
   usuario, contraseña, puerto y nombre de la base. Para respaldos desde el
   panel, crea `C:\ceicom-privado\backups` fuera de `htdocs`, indica esa ruta
   en `backup_directory` y la ruta del ejecutable de XAMPP en `mysqldump`.
6. Abre `http://localhost/ceicomphp/` y entra con una cuenta migrada. Si tu
   Apache usa otro puerto, inclúyelo en la URL.

Para archivos de planes de estudio grandes, configura `upload_max_filesize=20M`
y `post_max_size=24M` en PHP y `max_allowed_packet=64M` en MariaDB. Reinicia los
servicios tras editar su configuración.

Para empezar con una base nueva, omite la migración y crea un administrador inicial
desde PowerShell después de aplicar ambos esquemas y configurar la conexión:

```powershell
& C:\xampp\php\php.exe C:\xampp\htdocs\ceicomphp\app\create-admin.php "Nombre completo"
```

El comando genera una contraseña temporal. Para restaurar un respaldo SQL del
portal, impórtalo desde phpMyAdmin en una base nueva y vacía. El respaldo ya incluye
el esquema. Ajusta la conexión de la aplicación si decides usar esa base.
