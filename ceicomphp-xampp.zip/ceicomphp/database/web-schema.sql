CREATE TABLE IF NOT EXISTS login_attempts (
  address CHAR(64) PRIMARY KEY,
  attempts INT NOT NULL,
  expires BIGINT NOT NULL,
  INDEX (expires)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
