<?php

declare(strict_types=1);

$prefix = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
$request = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if (!is_string($request) || !str_starts_with($request, $prefix . '/api/')) {
    http_response_code(404);
    exit;
}

$_SERVER['CEICOM_PREFIX'] = $prefix;
$_SERVER['CEICOM_ROUTE'] = substr($request, strlen($prefix));
require __DIR__ . '/app/api.php';
