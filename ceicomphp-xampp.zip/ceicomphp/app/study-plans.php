<?php

declare(strict_types=1);

function portalPrefix(): string
{
    return rtrim($_SERVER['CEICOM_PREFIX'] ?? '', '/');
}

function planLinks(array $plan): array
{
    $plan = formatAcademicRow($plan);
    $path = portalPrefix() . '/api/study-plans/' . $plan['id'] . '/file';
    return $plan + ['view_url'=>$path,'download_url'=>$path.'?download=1'];
}

function studyPlans(Database $db, array $user, string $path, string $method): never
{
    if (!in_array($user['role'],['admin','teacher'],true)) {
        fail('Acceso restringido.',403);
    }
    $summary = 'SELECT p.id,p.title,p.career_id,UPPER(c.name) career,p.level,p.original_name,p.size_bytes,p.created_at
        FROM study_plans p JOIN careers c ON c.id=p.career_id';
    if ($path === '/api/study-plans' && $method === 'GET') {
        $conditions = [];
        $params = [];
        foreach (['career_id','level'] as $key) {
            if (isset($_GET[$key]) && $_GET[$key] !== '') {
                $id = positiveId($_GET[$key]);
                if ($key === 'level' && $id > 3) {
                    fail('El año académico debe ser 1, 2 o 3.');
                }
                $conditions[] = 'p.'.$key.'=?';
                $params[] = $id;
            }
        }
        if (isset($_GET['search']) && $_GET['search'] !== '') {
            $query = required($_GET['search'],'Búsqueda');
            $conditions[] = "LOCATE(?,CONCAT(p.title,' ',p.original_name,' ',c.name) COLLATE utf8mb4_unicode_ci)>0";
            $params[] = $query;
        }
        $where = $conditions ? ' WHERE '.implode(' AND ',$conditions) : '';
        jsonResponse(['plans'=>array_map('planLinks',$db->rows($summary.$where.' ORDER BY UPPER(c.name),p.level,p.created_at DESC,p.id DESC',$params))]);
    }
    if ($path === '/api/study-plans/upload' && $method === 'POST') {
        if ($user['role'] !== 'admin') {
            fail('Solo administración puede subir planes.',403);
        }
        $file = $_FILES['file'] ?? null;
        $limit = 20 * 1024 * 1024;
        if ((int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > $limit+65536 ||
            in_array($file['error'] ?? null,[UPLOAD_ERR_INI_SIZE,UPLOAD_ERR_FORM_SIZE],true)) {
            fail('El PDF debe pesar como máximo 20 MB.',413);
        }
        if (count($_FILES) !== 1 || ($file['error'] ?? null) !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) {
            fail('Selecciona un único PDF.');
        }
        $name = trim(preg_replace('/[\x00-\x1f\x7f]/','',basename(str_replace('\\','/',$file['name']))));
        if (!str_ends_with(strtolower($name),'.pdf') || mb_strlen($name)>200) {
            fail('El archivo debe tener extensión .pdf.',415);
        }
        $content = file_get_contents($file['tmp_name'],false,null,0,$limit+1);
        if (strlen($content)>$limit) {
            fail('El PDF debe pesar como máximo 20 MB.',413);
        }
        if (strlen($content)<16 || !preg_match('/^%PDF-[12]\.\d/',$content) || !str_contains(substr($content,-4096),'%%EOF')) {
            fail('El archivo no tiene un formato PDF válido.',422);
        }
        $title = upper(required($_POST['title'] ?? null,'Título'));
        $careerId = positiveId($_POST['career_id'] ?? null);
        $level = positiveId($_POST['level'] ?? null);
        if ($level>3 || !$db->first('SELECT id FROM careers WHERE id=?',[$careerId])) {
            fail('Selecciona una carrera registrada y un año académico válido.');
        }
        $plan = $db->transaction(function () use ($db,$user,$summary,$title,$careerId,$level,$name,$content) {
            $statement = $db->pdo->prepare('INSERT INTO study_plans(title,career_id,level,original_name,content,size_bytes,uploaded_by) VALUES (?,?,?,?,?,?,?)');
            $statement->bindValue(1,$title);
            $statement->bindValue(2,$careerId,PDO::PARAM_INT);
            $statement->bindValue(3,$level,PDO::PARAM_INT);
            $statement->bindValue(4,$name);
            $statement->bindValue(5,$content,PDO::PARAM_LOB);
            $statement->bindValue(6,strlen($content),PDO::PARAM_INT);
            $statement->bindValue(7,$user['id'],PDO::PARAM_INT);
            $statement->execute();
            $id = (int) $db->pdo->lastInsertId();
            $db->audit($user['id'],'Plan de estudio publicado',"Plan $id: $title");
            return $db->first($summary.' WHERE p.id=?',[$id]);
        });
        jsonResponse(planLinks($plan),201);
    }

    if (preg_match('~^/api/study-plans/([1-9][0-9]*)/(file|delete)$~D',$path,$match)) {
        $id = positiveId($match[1]);
        if ($method === 'GET' && $match[2] === 'file') {
            $plan = $db->first('SELECT content,size_bytes FROM study_plans WHERE id=?',[$id]);
            if (!$plan) {
                fail('El plan ya no está disponible. Actualiza la lista.',404);
            }
            $disposition = ($_GET['download'] ?? '') === '1' ? 'attachment' : 'inline';
            header('Content-Type: application/pdf');
            header("Content-Disposition: $disposition; filename=\"PLAN-$id.pdf\"");
            header('Content-Length: '.$plan['size_bytes']);
            echo $plan['content'];
            exit;
        }
        if ($method === 'POST' && $match[2] === 'delete') {
            if ($user['role'] !== 'admin') {
                fail('Solo administración puede eliminar planes.',403);
            }
            $db->transaction(function () use ($db,$user,$id) {
                if (!$db->run('DELETE FROM study_plans WHERE id=?',[$id])->rowCount()) {
                    fail('El plan ya no está disponible. Actualiza la lista.',404);
                }
                $db->audit($user['id'],'Plan de estudio eliminado',"Plan $id");
            });
            jsonResponse(['ok'=>true]);
        }
    }
    fail('Ruta no encontrada.',404);
}
