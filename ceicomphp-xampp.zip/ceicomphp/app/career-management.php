<?php

declare(strict_types=1);

function careerSnapshot(Database $db, int $id, bool $lock = false): array
{
    $locking = $lock ? ' FOR UPDATE' : '';
    $career = $db->first('SELECT * FROM careers WHERE id=?'.$locking,[$id]);
    if (!$career) {
        fail('Carrera no encontrada.',404);
    }
    $subjects = $db->rows('SELECT * FROM subjects WHERE career_id=? ORDER BY id'.$locking,[$id]);
    $subjectIds = array_column($subjects,'id');
    $subjectSql = idsSql($subjectIds);
    $offerings = $db->rows("SELECT o.*,m.name module,m.start_date,m.end_date,y.name AS `year`,sh.name shift,u.name teacher
        FROM offerings o JOIN modules m ON m.id=o.module_id JOIN years y ON y.id=m.year_id JOIN shifts sh ON sh.id=o.shift_id
        JOIN users u ON u.id=o.teacher_id WHERE o.subject_id IN ($subjectSql) ORDER BY o.id".$locking,$subjectIds);
    $offeringIds = array_column($offerings,'id');
    $offeringSql = idsSql($offeringIds);
    $enrollments = $db->rows("SELECT * FROM enrollments WHERE offering_id IN ($offeringSql) ORDER BY id".$locking,$offeringIds);
    $groups = $db->rows("SELECT g.*,y.name admission_year,sh.name shift FROM academic_groups g
        JOIN years y ON y.id=g.admission_year_id JOIN shifts sh ON sh.id=g.shift_id WHERE g.subject_id IN ($subjectSql) ORDER BY g.id".$locking,$subjectIds);
    $groupIds = array_column($groups,'id');
    $groupSql = idsSql($groupIds);
    $members = $db->rows("SELECT * FROM academic_group_students WHERE group_id IN ($groupSql) ORDER BY group_id,student_id".$locking,$groupIds);
    $series = $db->rows("SELECT * FROM subject_series WHERE subject_id IN ($subjectSql) ORDER BY id".$locking,$subjectIds);
    $profiles = $db->rows('SELECT * FROM students WHERE career_id=? ORDER BY user_id'.$locking,[$id]);
    $plans = $db->rows('SELECT id,title,level,original_name,size_bytes,uploaded_by,created_at FROM study_plans WHERE career_id=? ORDER BY id'.$locking,[$id]);
    $names = $db->rows('SELECT * FROM career_names WHERE career_id=? ORDER BY year_id'.$locking,[$id]);
    $subjectNames = array_column($subjects,'name','id');
    $groupOfferings = array_column($groups,'offering_id','id');
    $assigned = array_unique([...array_column($enrollments,'student_id'),...array_column($members,'student_id')]);
    $offeringStudents = $groupStudents = [];
    foreach ($enrollments as $row) {
        $offeringStudents[$row['offering_id']][$row['student_id']] = true;
    }
    foreach ($members as $row) {
        $groupStudents[$row['group_id']][$row['student_id']] = true;
        $offering = $groupOfferings[$row['group_id']];
        if ($offering !== null) {
            $offeringStudents[$offering][$row['student_id']] = true;
        }
    }
    $blocking = $pending = [];
    foreach ($offerings as $row) {
        $count = count($offeringStudents[$row['id']] ?? []);
        if ($count) {
            $detail = partRow($row + ['subject'=>$subjectNames[$row['subject_id']]]);
            $blocking[] = array_intersect_key($detail,array_flip(['id','subject','module','year','shift','teacher'])) + ['students'=>$count];
        }
    }
    foreach ($groups as $group) {
        if ($group['offering_id'] === null && !empty($groupStudents[$group['id']])) {
            $pending[] = [
                'id'=>$group['id'],'subject'=>upper($subjectNames[$group['subject_id']]),'admission_year'=>$group['admission_year'],
                'shift'=>upper($group['shift']),'students'=>count($groupStudents[$group['id']]),
            ];
        }
    }
    $public = [
        'career_id'=>$id,'name'=>upper($career['name']),'subjects'=>count($subjects),'offerings'=>count($offerings),
        'groups'=>count($groups),'series'=>count($series),'study_plans'=>count($plans),'student_profiles'=>count($profiles),
        'enrollments'=>count($enrollments),'assigned_students'=>count($assigned),'can_delete'=>!$assigned,
        'blocking_offerings'=>$blocking,'pending_groups'=>$pending,
        'revision'=>hash('sha256',json_encode([$career,$names,$subjects,$offerings,$enrollments,$groups,$members,$series,$profiles,$plans],JSON_THROW_ON_ERROR)),
    ];
    return compact('career','subjectIds','profiles','public');
}

function deleteCareer(Database $db, int $actor, array $input): array
{
    $id = positiveId($input['career_id'] ?? null);
    return $db->transaction(function () use ($db,$actor,$input,$id) {
        $state = careerSnapshot($db,$id,true);
        if (!$state['public']['can_delete']) {
            fail('No se puede eliminar la carrera: todavía hay estudiantes inscritos en sus materias o grupos.',409);
        }
        confirmReview($input,$state,'ELIMINAR CARRERA');
        if ($state['profiles']) {
            $destination = positiveId($input['destination_career_id'] ?? null);
            if ($destination === $id || !$db->first('SELECT id FROM careers WHERE id=? FOR UPDATE',[$destination])) {
                fail('Elige otra carrera registrada para conservar los perfiles de estudiantes.');
            }
            $db->run('UPDATE students SET career_id=? WHERE career_id=?',[$destination,$id]);
        }
        $ids = $state['subjectIds'];
        $sql = idsSql($ids);
        foreach (['academic_groups','offerings','subject_series'] as $table) {
            $db->run("DELETE FROM $table WHERE subject_id IN ($sql)",$ids);
        }
        $db->run('DELETE FROM subjects WHERE career_id=?',[$id]);
        $db->run('DELETE FROM study_plans WHERE career_id=?',[$id]);
        $db->run('DELETE FROM careers WHERE id=?',[$id]);
        $db->audit($actor,'Carrera eliminada',"Carrera $id: {$state['career']['name']}");
        return ['ok'=>true,'profiles_moved'=>count($state['profiles'])];
    });
}

function pendingGroupReview(Database $db, int $id): array
{
    $group = $db->first('SELECT g.*,s.name subject,COALESCE(n.name,c.name) career FROM academic_groups g
        JOIN subjects s ON s.id=g.subject_id JOIN careers c ON c.id=s.career_id
        LEFT JOIN career_names n ON n.career_id=c.id AND n.year_id=g.year_id WHERE g.id=? FOR UPDATE',[$id]);
    if (!$group) {
        fail('Grupo no encontrado.',404);
    }
    if ($group['offering_id'] !== null) {
        fail('Este grupo ya tiene una asignación. Usa Editar inscritos.',409);
    }
    $members = $db->rows('SELECT * FROM academic_group_students WHERE group_id=? ORDER BY student_id FOR UPDATE',[$id]);
    return [
        'group_id'=>$id,'subject'=>upper($group['subject']),'career'=>upper($group['career']),'students'=>count($members),
        'revision'=>hash('sha256',json_encode([$group,$members],JSON_THROW_ON_ERROR)),
    ];
}

function clearPendingGroup(Database $db, int $actor, array $input): array
{
    $id = positiveId($input['group_id'] ?? null);
    return $db->transaction(function () use ($db,$actor,$input,$id) {
        $review = pendingGroupReview($db,$id);
        confirmReview($input,['public'=>$review],'VACIAR GRUPO');
        $db->run('DELETE FROM academic_group_students WHERE group_id=?',[$id]);
        $db->audit($actor,'Grupo pendiente vaciado',"Grupo $id · {$review['students']} estudiantes retirados");
        return ['ok'=>true];
    });
}
