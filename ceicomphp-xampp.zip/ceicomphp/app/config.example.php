<?php

return [
    'mysql' => [
        'dsn' => 'mysql:host=127.0.0.1;port=3306;dbname=ceicomphp;charset=utf8mb4',
        'user' => 'root',
        'password' => '',
    ],
    'backup_directory' => 'C:/ceicom-privado/backups',
    'mysqldump' => 'C:/xampp/mysql/bin/mysqldump.exe',
];
