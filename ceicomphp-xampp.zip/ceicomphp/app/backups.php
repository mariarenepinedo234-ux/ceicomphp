<?php

declare(strict_types=1);

function backupInfo(string $path): array
{
    $name = basename($path);
    return [
        'filename'=>$name,'saved_path'=>'backups/'.$name,'size'=>filesize($path),
        'created_at'=>gmdate('Y-m-d\TH:i:s\Z',filemtime($path)),
        'download_url'=>portalPrefix().'/api/backups/'.$name,
    ];
}

function handleBackups(Database $db, array $user, array $config, string $path, string $method): never
{
    if ($user['role'] !== 'admin') {
        fail('Acceso restringido.',403);
    }
    $directory = $config['backup_directory'] ?? null;
    if (!is_string($directory) || !is_dir($directory) || !is_writable($directory)) {
        fail('Configura una carpeta privada y escribible para los respaldos.',503);
    }
    $directory = realpath($directory);
    $webRoot = realpath($_SERVER['DOCUMENT_ROOT']);
    $paths = array_map(static function ($path) {
        $normalized = rtrim(str_replace('\\','/',(string)$path),'/');
        return PHP_OS_FAMILY === 'Windows' ? strtolower($normalized) : $normalized;
    },[$directory,$webRoot]);
    if (!$directory || !$webRoot || str_starts_with($paths[0].'/', $paths[1].'/')) {
        fail('La carpeta de respaldos debe estar fuera de la raíz web.',503);
    }
    $pattern = '/^ceicom-\d{8}T\d{6}Z-[a-f0-9]{12}\.sql$/D';
    if ($path === '/api/backups' && $method === 'GET') {
        $files = [];
        foreach (new DirectoryIterator($directory) as $file) {
            if ($file->isFile() && !$file->isLink() && preg_match($pattern,$file->getFilename())) {
                $files[] = backupInfo($file->getPathname());
            }
        }
        usort($files,static fn($a,$b) => strcmp($b['filename'],$a['filename']));
        jsonResponse(['backups'=>$files]);
    }
    if ($path === '/api/backups' && $method === 'POST') {
        $name = 'ceicom-'.gmdate('Ymd\THis\Z').'-'.bin2hex(random_bytes(6)).'.sql';
        $file = $directory.DIRECTORY_SEPARATOR.$name;
        createBackup($db,$config,$file);
        $db->audit($user['id'],'Copia de seguridad creada',$name);
        jsonResponse(backupInfo($file),201);
    }
    $name = substr($path,strlen('/api/backups/'));
    $file = $directory.DIRECTORY_SEPARATOR.$name;
    if ($method !== 'GET' || !preg_match($pattern,$name) || !is_file($file) || is_link($file)) {
        fail('Copia de seguridad no encontrada.',404);
    }
    $db->audit($user['id'],'Copia de seguridad descargada',$name);
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="'.$name.'"');
    header('Content-Length: '.filesize($file));
    readfile($file);
    exit;
}

function createBackup(Database $db, array $config, string $file): void
{
    $dbName = $db->pdo->query('SELECT DATABASE()')->fetchColumn();
    $options = $config['mysql'];
    $parts = [];
    foreach (explode(';',substr($options['dsn'],6)) as $pair) {
        if (str_contains($pair,'=')) {
            [$key,$value] = explode('=',$pair,2);
            $parts[$key] = $value;
        }
    }
    $binary = $config['mysqldump'] ?? 'mysqldump';
    $lock = fopen(dirname($file).'/.backup.lock','c');
    if (!$lock || !flock($lock,LOCK_EX|LOCK_NB)) {
        fail('Ya se está generando una copia de seguridad.',409);
    }
    $temp = null;
    try {
        $temp = tempnam(dirname($file),'.backup-config-');
        if ($temp === false) {
            fail('No se pudo preparar la copia de seguridad.',503);
        }
        $optionText = "[client]\n";
        foreach (['host'=>$parts['host'] ?? '127.0.0.1','port'=>$parts['port'] ?? '3306','user'=>$options['user'],'password'=>$options['password']] as $key=>$value) {
            $quoted = strtr($value,["\\"=>"\\\\",'"'=>'\\"',"\n"=>'\\n',"\r"=>'\\r',"\t"=>'\\t']);
            $optionText .= $key.'="'.$quoted."\"\n";
        }
        chmod($temp,0600);
        if (file_put_contents($temp,$optionText) === false) {
            fail('No se pudo preparar la copia de seguridad.',503);
        }
        $cmd = [$binary,'--defaults-file='.$temp,'--single-transaction','--hex-blob','--skip-add-drop-table','--no-tablespaces',
            '--ignore-table='.$dbName.'.sessions','--ignore-table='.$dbName.'.login_attempts','--',$dbName];
        $process = proc_open($cmd,[0=>['pipe','r'],1=>['file',$file.'.partial','w'],2=>['file',PHP_OS_FAMILY === 'Windows' ? 'NUL' : '/dev/null','w']],$pipes);
        if (!is_resource($process)) {
            fail('No se pudo iniciar mysqldump. Revisa la configuración.',503);
        }
        fclose($pipes[0]);
        if (proc_close($process) !== 0 || !filesize($file.'.partial')) {
            fail('No se pudo generar la copia. Revisa la ruta y los permisos de mysqldump.',503);
        }
        foreach (['sessions','login_attempts'] as $table) {
            $definition = $db->pdo->query('SHOW CREATE TABLE '.$table)->fetch(PDO::FETCH_NUM)[1];
            if (file_put_contents($file.'.partial',"\n".$definition.";\n",FILE_APPEND) === false) {
                fail('No se pudo completar la copia de seguridad.',503);
            }
        }
        if (!rename($file.'.partial',$file)) {
            fail('No se pudo generar la copia. Revisa la ruta y los permisos de mysqldump.',503);
        }
    } finally {
        if (is_string($temp) && is_file($temp)) {
            unlink($temp);
        }
        if (is_file($file.'.partial')) {
            unlink($file.'.partial');
        }
        fclose($lock);
    }
}
