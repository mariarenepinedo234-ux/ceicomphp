<?php

declare(strict_types=1);

use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
use PhpOffice\PhpSpreadsheet\RichText\RichText;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

function catalogKey(string $value): string
{
    return strtr(normalizedName($value),['Á'=>'A','É'=>'E','Í'=>'I','Ó'=>'O','Ú'=>'U','Ü'=>'U','Ñ'=>'N']);
}

function catalogCareerKey(string $value): string
{
    $key = catalogKey($value);
    return $key === 'COMERCIO INTERNACIONAL' ? 'COMERCIO INTERNACIONAL Y ADMINISTRACION ADUANERA' : $key;
}

function catalogTeacherKey(string $value): string
{
    return preg_replace('/^(LIC|ING|DR|DRA|MSC|TEC)\.?\s+/','',catalogKey($value));
}

function catalogCell(Worksheet $sheet, int $row, int $column): string
{
    $cell = $sheet->getCell([$column,$row]);
    $merge = $cell->getMergeRange();
    if ($merge !== false && !$cell->isMergeRangeValueCell()) {
        $cell = $sheet->getCell(explode(':',$merge)[0]);
    }
    if ($cell->getDataType() === DataType::TYPE_FORMULA) {
        return '';
    }
    $value = $cell->getValue();
    if ($value instanceof RichText) {
        $value = $value->getPlainText();
    }
    return is_string($value) || is_int($value) || is_float($value) ? trim(preg_replace('/\s+/u',' ',(string)$value)) : '';
}

function readCatalogWorkbook(string $content): array
{
    if (strlen($content)>2097152 || !str_starts_with($content,"PK\x03\x04")) {
        fail('Adjunta un archivo .xlsx válido de hasta 2 MB.');
    }
    require_once __DIR__.'/vendor/autoload.php';
    $path = tempnam(sys_get_temp_dir(),'ceicom-catalog-');
    if ($path === false) {
        fail('No se pudo abrir el archivo para revisión.',503);
    }
    $book = null;
    try {
        if (file_put_contents($path,$content) === false) {
            fail('No se pudo abrir el archivo para revisión.',503);
        }
        $zip = new ZipArchive();
        if ($zip->open($path,ZipArchive::RDONLY) !== true) {
            fail('No se pudo reconocer el archivo Excel.');
        }
        try {
            $size = 0;
            if ($zip->numFiles>250) {
                fail('El Excel supera el tamaño permitido al descomprimir.');
            }
            for ($i=0;$i<$zip->numFiles;$i++) {
                $size += $zip->statIndex($i)['size'];
                if ($size>41943040) {
                    fail('El Excel supera el tamaño permitido al descomprimir.');
                }
            }
        } finally {
            $zip->close();
        }
        $reader = new Xlsx();
        $sheets = array_values(array_filter($reader->listWorksheetNames($path),static fn($name) => catalogKey($name)==='BASE DE DATOS'));
        if (!$sheets) {
            fail('Falta la hoja BASE DE DATOS. Usa el formato de la planilla institucional.');
        }
        $reader->setLoadSheetsOnly($sheets[0])->setReadEmptyCells(false);
        $book = $reader->load($path);
        return parseCatalogSheet($book->getSheet(0));
    } catch (\PhpOffice\PhpSpreadsheet\Reader\Exception $e) {
        fail('No se pudo reconocer el archivo Excel.');
    } finally {
        $book?->disconnectWorksheets();
        unlink($path);
    }
}

function parseCatalogSheet(Worksheet $sheet): array
{
    $rows = $sheet->getHighestDataRow();
    $columns = Coordinate::columnIndexFromString($sheet->getHighestDataColumn());
    if ($rows>5000 || $columns>60) {
        fail('La hoja supera el límite de filas o columnas.');
    }
    $careers = $teachers = $subjects = $heads = $seen = $warnings = [];
    $section = '';
    for ($row=1;$row<=$rows;$row++) {
        $label = catalogCell($sheet,$row,2);
        $key = catalogKey($label);
        if (in_array($key,['CARRERAS','DOCENTE','DOCENTES'],true)) {
            $section = $key;
        } elseif (in_array($key,['TURNO','CURSO','TRIMESTRE'],true)) {
            $section = '';
        } elseif ($label !== '') {
            if ($section==='CARRERAS') {
                $careers[catalogCareerKey($label)] ??= $label;
            } elseif ($section==='DOCENTE' || $section==='DOCENTES') {
                $teachers[catalogTeacherKey($label)] ??= $label;
            }
        }
    }
    if (!$careers) {
        fail('No se encontró la lista de carreras en la columna B.');
    }
    for ($row=1;$row<=$rows;$row++) {
        for ($column=4;$column<=$columns;$column++) {
            $name = upper(catalogCell($sheet,$row,$column));
            if ($name === '') {
                continue;
            }
            $code = upper(catalogCell($sheet,$row,$column+1));
            $address = Coordinate::stringFromColumnIndex($column).$row;
            if (catalogKey($code)==='CODIGO') {
                if (!preg_match('/^(.*?)\s+(1ER|2DO|3ER|PRIMER|PRIMERO|SEGUNDO|TERCER|TERCERO)\s+ANO$/D',catalogKey($name),$matches)) {
                    fail("No se reconoce carrera/año en $address.");
                }
                $career = $careers[catalogCareerKey($matches[1])] ?? null;
                if ($career===null) {
                    fail("El encabezado de $address no coincide con la lista de carreras.");
                }
                $level = preg_match('/^(1|PRIM)/',$matches[2]) ? 1 : (preg_match('/^(2|SEG)/',$matches[2]) ? 2 : 3);
                $heads[$column] = compact('career','level');
                continue;
            }
            if (!isset($heads[$column])) {
                continue;
            }
            if ($code==='') {
                $warnings[] = "Sin código en $address; no se importó esa celda.";
                continue;
            }
            if (mb_strlen($name)>160 || !preg_match('~^[A-Z0-9][A-Z0-9._/-]{0,39}$~D',$code)) {
                fail("Materia o código inválido en fila $row.");
            }
            $subject = $heads[$column] + compact('name','code');
            $identity = catalogCareerKey($subject['career']).'|'.$subject['level'].'|'.$code;
            if (isset($seen[$identity])) {
                if ($seen[$identity]!==catalogKey($name)) {
                    fail("Código repetido con distinto nombre en fila $row.");
                }
                continue;
            }
            $seen[$identity] = catalogKey($name);
            $subjects[] = $subject;
        }
    }
    if (!$subjects) {
        fail('No se encontraron materias con códigos.');
    }
    foreach ([...$careers,...$teachers] as $name) {
        if (mb_strlen($name)>160) {
            fail('Un nombre excede 160 caracteres.');
        }
    }
    $summary = $missing = [];
    $counts = [];
    foreach ($subjects as $subject) {
        $career = $subject['career'];
        $level = $subject['level'];
        $counts[$career][$level] = ($counts[$career][$level] ?? 0)+1;
    }
    foreach ($careers as $name) {
        $levels = [];
        foreach ([1,2,3] as $level) {
            $levels[] = ['level'=>$level,'count'=>$counts[$name][$level] ?? 0];
        }
        $summary[] = compact('name','levels');
        if (!isset($counts[$name])) {
            $missing[] = $name;
        }
    }
    return ['careers'=>array_values($careers),'subjects'=>$subjects,'teachers'=>array_values($teachers),'summary'=>$summary,'missing'=>$missing,'warnings'=>$warnings];
}

function catalogPreview(Database $db, int $actor, array $input): array
{
    $base64 = $input['file'] ?? null;
    $content = is_string($base64) ? base64_decode($base64,true) : false;
    if ($content === false || $content === '') {
        fail('Selecciona un archivo Excel.');
    }
    $payload = readCatalogWorkbook($content);
    $token = bin2hex(random_bytes(24));
    $db->transaction(function () use ($db,$actor,$token,$payload) {
        $db->first('SELECT id FROM users WHERE id=? FOR UPDATE',[$actor]);
        $db->run('DELETE FROM catalog_import_batches WHERE actor_id=? AND (expires_at<CURRENT_TIMESTAMP OR applied_at IS NOT NULL)',[$actor]);
        if ($db->first('SELECT COUNT(*) n FROM catalog_import_batches WHERE actor_id=?',[$actor])['n']>=5) {
            fail('Tienes varias vistas previas abiertas. Espera 15 minutos o confirma una.');
        }
        $db->run('INSERT INTO catalog_import_batches(token,actor_id,payload,expires_at) VALUES (?,?,?,DATE_ADD(CURRENT_TIMESTAMP,INTERVAL 15 MINUTE))',
            [hash('sha256',$token),$actor,json_encode($payload,JSON_THROW_ON_ERROR)]);
    });
    return ['token'=>$token]+$payload;
}

function catalogApply(Database $db, int $actor, array $input): array
{
    $token = hash('sha256',required($input['token'] ?? null,'Vista previa'));
    return $db->transaction(function () use ($db,$actor,$token) {
        $batch = $db->first('SELECT payload,applied_at FROM catalog_import_batches WHERE token=? AND actor_id=? AND expires_at>CURRENT_TIMESTAMP FOR UPDATE',[$token,$actor]);
        if (!$batch || $batch['applied_at']!==null) {
            fail('La vista previa venció o ya fue aplicada. Selecciona el archivo de nuevo.');
        }
        $payload = json_decode($batch['payload'],true,512,JSON_THROW_ON_ERROR);
        $result = array_fill_keys(['careers_created','careers_renamed','subjects_created','subjects_updated','subjects_reordered','teachers_pending','teachers_linked'],0);
        $careers = $db->rows('SELECT * FROM careers ORDER BY id FOR UPDATE');
        $ids = [];
        foreach ($payload['careers'] as $name) {
            $key = catalogCareerKey($name);
            $matches = array_values(array_filter($careers,static fn($row) => catalogCareerKey($row['name'])===$key));
            if (count($matches)>1) {
                fail('Hay dos carreras equivalentes registradas. Revisa el catálogo antes de importar.');
            }
            $previous = $matches[0] ?? null;
            if (!$previous) {
                $db->run('INSERT INTO careers(name) VALUES (?)',[$name]);
                $ids[$key] = (int)$db->pdo->lastInsertId();
                $result['careers_created']++;
                continue;
            }
            $ids[$key] = $previous['id'];
            if ($previous['name']!==$name) {
                $db->run('UPDATE careers SET name=? WHERE id=?',[$name,$previous['id']]);
                $result['careers_renamed']++;
            }
        }
        $positions = [];
        foreach ($payload['subjects'] as $subject) {
            $career = $ids[catalogCareerKey($subject['career'])];
            $level = $subject['level'];
            $code = $subject['code'];
            $name = upper($subject['name']);
            $position = $positions["$career|$level"] = ($positions["$career|$level"] ?? 0)+1;
            $old = $db->first('SELECT * FROM subjects WHERE career_id=? AND level=? AND code_key=? FOR UPDATE',[$career,$level,$code]);
            if (!$old) {
                $matches = array_values(array_filter(
                    $db->rows('SELECT * FROM subjects WHERE career_id=? AND level=? AND code IS NULL FOR UPDATE',[$career,$level]),
                    static fn($row) => catalogKey($row['name'])===catalogKey($name)
                ));
                if (count($matches)>1) {
                    fail('Una materia sin código coincide con varios registros. Revísala antes de importar.');
                }
                $old = $matches[0] ?? null;
            }
            if ($old) {
                $changed = $old['name']!==$name || $old['code']!==$code;
                $reordered = $old['catalog_order']!==$position;
                $result['subjects_updated'] += (int)$changed;
                $result['subjects_reordered'] += (int)$reordered;
                if ($changed || $reordered) {
                    $db->run('UPDATE subjects SET name=?,code=?,catalog_order=? WHERE id=?',[$name,$code,$position,$old['id']]);
                }
            } else {
                $db->run('INSERT INTO subjects(name,career_id,level,code,catalog_order) VALUES (?,?,?,?,?)',[$name,$career,$level,$code,$position]);
                $result['subjects_created']++;
            }
        }
        $users = $db->rows("SELECT id,name FROM users WHERE role='teacher'");
        foreach ($payload['teachers'] as $name) {
            $key = catalogTeacherKey($name);
            if ($db->first('SELECT id FROM teacher_directory WHERE name_key=?',[$key])) {
                continue;
            }
            $matching = array_values(array_filter($users,static fn($row) => catalogTeacherKey($row['name'])===$key));
            $user = count($matching)===1 ? $matching[0]['id'] : null;
            $db->run('INSERT INTO teacher_directory(name,name_key,user_id) VALUES (?,?,?)',[$name,$key,$user]);
            $result[$user ? 'teachers_linked' : 'teachers_pending']++;
        }
        $db->run('UPDATE catalog_import_batches SET applied_at=CURRENT_TIMESTAMP WHERE token=?',[$token]);
        $db->audit($actor,'Catálogo Excel importado',json_encode($result,JSON_THROW_ON_ERROR));
        return $result;
    });
}

function activateDirectoryTeacher(Database $db, int $actor, array $input): array
{
    $id = positiveId($input['directory_id'] ?? null);
    $ci = required($input['ci'] ?? null,'CI');
    if (mb_strlen($ci)<5 || mb_strlen($ci)>40) {
        fail('Ingresa un CI válido (entre 5 y 40 caracteres).');
    }
    return $db->transaction(function () use ($db,$actor,$id,$ci) {
        $entry = $db->first('SELECT * FROM teacher_directory WHERE id=? FOR UPDATE',[$id]);
        if (!$entry) {
            fail('Docente no encontrado.',404);
        }
        if ($entry['user_id'] !== null) {
            $user = $db->first("SELECT ci FROM users WHERE id=? AND role='teacher' FOR UPDATE",[$entry['user_id']]);
            if (!$user || $user['ci']!==null) {
                fail('Este docente ya tiene cuenta o el vínculo es inválido.');
            }
            $db->run('UPDATE users SET ci=?,password=?,must_change=1 WHERE id=?',[$ci,hashCeicomPassword($ci),$entry['user_id']]);
        } else {
            $db->run("INSERT INTO users(ci,name,role,password) VALUES (?,?,'teacher',?)",[$ci,$entry['name'],hashCeicomPassword($ci)]);
            $db->run('UPDATE teacher_directory SET user_id=? WHERE id=?',[(int)$db->pdo->lastInsertId(),$id]);
        }
        $db->audit($actor,'Cuenta docente habilitada',"Registro docente $id");
        return ['ok'=>true];
    });
}
