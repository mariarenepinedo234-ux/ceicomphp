<?php

declare(strict_types=1);

final class HttpError extends RuntimeException {}

function fail(string $message, int $status = 400): never
{
    throw new HttpError($message, $status);
}

function jsonResponse(array $data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_THROW_ON_ERROR | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function upper(string $text): string
{
    return mb_strtoupper($text, 'UTF-8');
}

function required(mixed $value, string $label): string
{
    if (!is_string($value) || trim($value) === '' || mb_strlen($value) > 160) {
        fail("$label: valor requerido (máximo 160 caracteres).");
    }
    return trim($value);
}

function positiveId(mixed $value): int
{
    if (!is_int($value) && !is_string($value)) {
        fail('Selecciona una opción válida.');
    }
    $number = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 2147483647]]);
    if ($number === false) {
        fail('Selecciona una opción válida.');
    }
    return $number;
}

function acceptsTrue(mixed $value): bool
{
    return $value === true || $value === 'true';
}

final class Database
{
    public function __construct(public readonly PDO $pdo) {}

    public static function connect(array $config): self
    {
        $pdo = new PDO($config['dsn'], $config['user'], $config['password'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        $pdo->exec("SET SESSION sql_mode = 'STRICT_ALL_TABLES,NO_ENGINE_SUBSTITUTION'");
        $pdo->exec("SET time_zone = '+00:00'");
        return new self($pdo);
    }

    public function run(string $sql, array $params = []): PDOStatement
    {
        $statement = $this->pdo->prepare($sql);
        foreach (array_values($params) as $index => $value) {
            $type = match (true) {
                $value === null => PDO::PARAM_NULL,
                is_int($value), is_bool($value) => PDO::PARAM_INT,
                default => PDO::PARAM_STR,
            };
            $statement->bindValue($index + 1, $value, $type);
        }
        $statement->execute();
        return $statement;
    }

    public function rows(string $sql, array $params = []): array
    {
        return $this->run($sql, $params)->fetchAll();
    }

    public function first(string $sql, array $params = []): ?array
    {
        return $this->run($sql, $params)->fetch() ?: null;
    }

    public function transaction(callable $callback): mixed
    {
        $this->pdo->beginTransaction();
        try {
            $result = $callback();
            $this->pdo->commit();
            return $result;
        } catch (Throwable $error) {
            $this->pdo->rollBack();
            throw $error;
        }
    }

    public function audit(int $actor, string $action, string $detail): void
    {
        $this->run('INSERT INTO audit(actor_id,action,detail) VALUES (?,?,?)', [$actor,$action,$detail]);
    }
}

function verifyCeicomPassword(string $password, ?string $stored): bool
{
    if ($stored === null) {
        return false;
    }
    if (preg_match('/^([0-9a-f]{32}):([0-9a-f]{128})$/D', $stored, $parts)) {
        // Node usa scrypt N=16384,r=8,p=1 y el salt hexadecimal como texto ASCII.
        $key = sodium_crypto_pwhash_scryptsalsa208sha256(64, $password, $parts[1], 524288, 16777216);
        return hash_equals(hex2bin($parts[2]), $key);
    }
    return password_verify($password, $stored);
}

function publicUser(array $user): array
{
    return [
        'id' => $user['id'], 'ci' => $user['ci'], 'name' => upper($user['name']), 'role' => $user['role'],
        'must_change' => (bool) $user['must_change'], 'blocked' => (bool) $user['blocked'],
    ];
}

function sessionCookie(string $value, int $expires): void
{
    setcookie('ceicom_session', $value, [
        'expires' => $expires, 'path' => ($_SERVER['CEICOM_PREFIX'] ?? '') . '/', 'httponly' => true, 'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
}

function deadline(string $endDate): DateTimeImmutable
{
    $date = new DateTimeImmutable($endDate . ' 23:59:59', new DateTimeZone('America/La_Paz'));
    for ($remaining = 3; $remaining > 0;) {
        $date = $date->modify('+1 day');
        if ((int) $date->format('N') < 6) {
            $remaining--;
        }
    }
    return $date;
}

function canGrade(string $endDate, ?string $unlock): bool
{
    return time() <= deadline($endDate)->getTimestamp() || ($unlock !== null && time() <= strtotime($unlock));
}

function hashCeicomPassword(string $password): string
{
    $salt = bin2hex(random_bytes(16));
    return $salt . ':' . bin2hex(sodium_crypto_pwhash_scryptsalsa208sha256(64, $password, $salt, 524288, 16777216));
}
