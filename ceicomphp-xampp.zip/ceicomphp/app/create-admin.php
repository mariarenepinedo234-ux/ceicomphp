<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/support.php';
$configFile = getenv('CEICOM_CONFIG') ?: __DIR__ . '/config.local.php';
if (!is_file($configFile)) {
    fwrite(STDERR,"Configura config.local.php antes de crear una cuenta.\n");
    exit(1);
}
try {
    $config = require $configFile;
    $db = Database::connect($config['mysql']);
    $name = upper(required($argv[1] ?? null,'Nombre'));
    $ci = required($argv[2] ?? 'admin','Usuario');
    $password = bin2hex(random_bytes(12));
    $db->transaction(function () use ($db,$name,$ci,$password) {
        // Bloquea la comprobación de la primera cuenta en la misma transacción.
        if ($db->rows('SELECT id,role FROM users ORDER BY id FOR UPDATE')) {
            fail('La base ya tiene cuentas. Usa una cuenta migrada.');
        }
        $db->run("INSERT INTO users(ci,name,role,password) VALUES (?,?,'admin',?)",[$ci,$name,hashCeicomPassword($password)]);
        $db->audit((int)$db->pdo->lastInsertId(),'Administrador inicial creado',$name);
    });
    fwrite(STDOUT,"Usuario: $ci\nContraseña temporal: $password\nEl portal te pedirá cambiarla al iniciar sesión.\n");
} catch (HttpError $error) {
    fwrite(STDERR,$error->getMessage()."\n");
    exit(1);
} catch (Throwable $error) {
    fwrite(STDERR,"No se pudo crear el administrador. Verifica el esquema y la conexión.\n");
    exit(1);
}
