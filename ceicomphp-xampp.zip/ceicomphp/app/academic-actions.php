<?php

declare(strict_types=1);

function saveGrades(Database $db, array $user, array $input): void
{
    if (!in_array($user['role'], ['admin','teacher'], true)) {
        fail('Acceso restringido.', 403);
    }
    $offeringId = positiveId($input['offering_id'] ?? null);
    $items = $input['grades'] ?? null;
    if (!is_array($items) || !$items || !array_is_list($items)) {
        fail('No hay notas para guardar.');
    }
    $rows = [];
    foreach ($items as $item) {
        if (!is_array($item)) {
            fail('Nota inválida.');
        }
        $id = positiveId($item['id'] ?? null);
        if (isset($rows[$id])) {
            fail('Una inscripción aparece más de una vez.');
        }
        $rows[$id] = gradeValues($item);
    }
    ksort($rows, SORT_NUMERIC);

    $db->transaction(function () use ($db,$user,$offeringId,$rows) {
        $offering = $db->first('SELECT o.teacher_id,o.unlocked_until,m.end_date FROM offerings o JOIN modules m ON m.id=o.module_id WHERE o.id=? FOR UPDATE', [$offeringId]);
        if (!$offering) {
            fail('Materia no encontrada.', 404);
        }
        if ($user['role'] === 'teacher' && $offering['teacher_id'] !== $user['id']) {
            fail('No tienes esta materia asignada.', 403);
        }
        if ($user['role'] === 'teacher' && !canGrade($offering['end_date'], $offering['unlocked_until'])) {
            fail('El plazo finalizó. Solicita una reapertura al administrador.', 403);
        }
        foreach ($rows as $id => [$saber,$hacer,$ser,$grade]) {
            $previous = $db->first('SELECT grade FROM enrollments WHERE id=? AND offering_id=? FOR UPDATE', [$id,$offeringId]);
            if (!$previous) {
                fail('Inscripción inválida.');
            }
            $db->run('UPDATE enrollments SET saber=?,hacer=?,ser=?,grade=?,updated_at=CURRENT_TIMESTAMP(6) WHERE id=?', [$saber,$hacer,$ser,$grade,$id]);
            $db->audit($user['id'],$grade === null ? 'Borrador de notas guardado' : 'Nota registrada',
                "Inscripción $id: " . ($previous['grade'] ?? 'pendiente') . ' → ' . ($grade ?? 'pendiente') .
                '. Saber ' . ($saber ?? '—') . ', Hacer ' . ($hacer ?? '—') . ', Ser ' . ($ser ?? '—'));
        }
    });
}

function gradeValues(array $item): array
{
    $dimensions = ['saber'=>40,'hacer'=>40,'ser'=>20];
    $values = [null,null,null];
    $grade = $item['grade'] ?? null;
    $hasDimensions = (bool) array_intersect_key($dimensions, $item);
    if ($hasDimensions) {
        $values = [];
        foreach ($dimensions as $key => $limit) {
            $value = $item[$key] ?? null;
            if (!array_key_exists($key,$item) || ($value !== null &&
                ((!is_int($value) && !is_float($value)) || $value < 0 || $value > $limit || abs($value * 100 - round($value * 100)) > 1e-7))) {
                fail(ucfirst($key) . " debe estar entre 0 y $limit, con un máximo de dos decimales.");
            }
            $values[] = $value;
        }
        $grade = in_array(null,$values,true) ? null : round(array_sum($values),2);
    }
    if ((!$hasDimensions || $grade !== null) && ((!is_int($grade) && !is_float($grade)) || $grade < 1 || $grade > 100)) {
        fail('La nota final debe estar entre 1 y 100.');
    }
    return [...$values,$grade];
}

function normalizedName(string $name): string
{
    return upper(preg_replace('/\s+/u',' ',trim($name)));
}

function editCareerName(Database $db, int $actor, array $input): array
{
    $careerId = positiveId($input['career_id'] ?? null);
    $yearId = positiveId($input['year_id'] ?? null);
    $name = normalizedName(required($input['name'] ?? null,'Nombre'));
    return $db->transaction(function () use ($db,$actor,$input,$careerId,$yearId,$name) {
        // Serializa la reserva de nombres entre carreras.
        $db->rows('SELECT id FROM careers ORDER BY id FOR UPDATE');
        $career = $db->first('SELECT * FROM careers WHERE id=?',[$careerId]);
        if (!$career || !$db->first('SELECT id FROM years WHERE id=?',[$yearId])) {
            fail('Selecciona una carrera y una gestión registradas.');
        }
        $old = $db->first('SELECT name FROM career_names WHERE career_id=? AND year_id=?',[$careerId,$yearId])['name'] ?? $career['name'];
        if (!is_string($input['expected_name'] ?? null) || normalizedName($input['expected_name']) !== normalizedName($old)) {
            fail('El nombre cambió en esta gestión. Vuelve a abrir Editar carrera.',409);
        }
        $peers = $db->rows('SELECT COALESCE(n.name,c.name) name FROM careers c LEFT JOIN career_names n ON n.career_id=c.id AND n.year_id=? WHERE c.id<>?',[$yearId,$careerId]);
        foreach ($peers as $peer) {
            if (normalizedName($peer['name']) === $name) {
                fail('Ya existe otra carrera con ese nombre en esta gestión.',409);
            }
        }
        $db->run('INSERT INTO career_names(career_id,year_id,name) VALUES (?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name)',[$careerId,$yearId,$name]);
        $db->audit($actor,'Carrera editada',"Carrera $careerId, gestión $yearId: $old → $name");
        return ['ok'=>true];
    });
}

function assertCareerName(Database $db, string $name, int $except = 0): void
{
    $rows = $db->rows('SELECT name FROM careers WHERE id<>? UNION ALL SELECT name FROM career_names WHERE career_id<>?',[$except,$except]);
    foreach ($rows as $row) {
        if (normalizedName($row['name']) === $name) {
            fail('Ya existe una carrera con ese nombre, incluso entre sus nombres por gestión.',409);
        }
    }
}

function enrollStudent(Database $db, int $actor, array $input): array
{
    $studentId = positiveId($input['student_id'] ?? null);
    $offeringId = positiveId($input['offering_id'] ?? null);
    return $db->transaction(function () use ($db,$actor,$input,$studentId,$offeringId) {
        $o = $db->first('SELECT o.*,s.career_id,s.level FROM offerings o JOIN subjects s ON s.id=o.subject_id WHERE o.id=? FOR UPDATE',[$offeringId]);
        $s = $db->first('SELECT * FROM students WHERE user_id=? FOR UPDATE',[$studentId]);
        if (!$s || !$o) {
            fail('Estudiante o materia inválidos.');
        }
        $group = $db->first('SELECT * FROM academic_groups WHERE offering_id=? FOR UPDATE',[$offeringId]);
        $retake = $s['level'] > $o['level'];
        $cohort = $group['admission_year_id'] ?? null;
        if ($s['career_id'] !== $o['career_id'] || $s['shift_id'] !== $o['shift_id'] ||
            ($retake && !acceptsTrue($input['allow_retake'] ?? null)) ||
            (!$retake && ($s['level'] !== $o['level'] || ($cohort !== null && $cohort !== $s['admission_year_id'])))) {
            fail('La materia debe coincidir con carrera, turno y año. Para cursar un año anterior activa Materia pendiente; no se permite adelantar años.');
        }
        if (!$retake && !calendarAcceptsAdmission($db,$db->first('SELECT * FROM modules WHERE id=?',[$o['module_id']]),$s['admission_year_id'])) {
            fail('Esta asignación usa otro calendario. Elige el módulo correspondiente al ingreso del estudiante.');
        }
        if ($db->first('SELECT id FROM enrollments WHERE student_id=? AND offering_id=?',[$studentId,$offeringId])) {
            fail('El estudiante ya está inscrito en esta asignación. Para otro intento usa una asignación de otro trimestre o gestión.');
        }
        $db->run('INSERT INTO enrollments(student_id,offering_id,is_retake) VALUES (?,?,?)',[$studentId,$offeringId,(int)$retake]);
        if ($group) {
            $db->run('INSERT INTO academic_group_students(group_id,student_id) VALUES (?,?) ON DUPLICATE KEY UPDATE student_id=VALUES(student_id)',[$group['id'],$studentId]);
        }
        $db->audit($actor,$retake ? 'Materia pendiente inscrita' : 'Inscripción realizada',"Estudiante $studentId · asignación $offeringId");
        return ['ok'=>true];
    });
}

function adminAction(Database $db, int $actor, string $path, array $body): ?array
{
    return match ($path) {
        '/api/career-edit' => editCareerName($db,$actor,$body),
        '/api/enrollments' => enrollStudent($db,$actor,$body),
        '/api/catalog' => createCatalogEntry($db,$actor,$body),
        '/api/users' => createUser($db,$actor,$body),
        '/api/offerings' => createOffering($db,$actor,$body),
        '/api/subjects' => saveSubjects($db,$actor,$body),
        '/api/modules' => saveModule($db,$actor,$body,null),
        '/api/module-edit' => saveModule($db,$actor,$body,positiveId($body['module_id'] ?? null)),
        '/api/rosters' => saveRegisteredGroup($db,$actor,$body),
        '/api/student-edit', '/api/student-profile' => saveStudentProfile($db,$actor,$body,$path === '/api/student-edit'),
        '/api/student-password-reset', '/api/teacher-password-reset' => resetPortalPassword($db,$actor,$body,$path === '/api/student-password-reset' ? 'student' : 'teacher'),
        '/api/student-status', '/api/transfer' => changeStudentStatus($db,$actor,$body,$path),
        '/api/offering-roster' => updateOfferingRoster($db,$actor,$body),
        '/api/student-delete' => deleteAcademicRecord($db,$actor,'student',$body),
        '/api/offering-delete' => deleteAcademicRecord($db,$actor,'offering',$body),
        '/api/module-delete' => deleteAcademicRecord($db,$actor,'module',$body),
        '/api/subject-parts' => saveSubjectPart($db,$actor,$body),
        '/api/subject-parts/link' => linkSubjectPart($db,$actor,$body),
        '/api/subject-series/status' => editSeriesStatus($db,$actor,$body),
        '/api/career-delete' => deleteCareer($db,$actor,$body),
        '/api/pending-group-clear' => clearPendingGroup($db,$actor,$body),
        '/api/catalog-excel/preview' => catalogPreview($db,$actor,$body),
        '/api/catalog-excel/apply' => catalogApply($db,$actor,$body),
        '/api/teacher-directory/activate' => activateDirectoryTeacher($db,$actor,$body),
        '/api/unlock' => unlockOffering($db,$actor,$body),
        default => null,
    };
}

function createCatalogEntry(Database $db, int $actor, array $input): array
{
    $tables = ['career'=>'careers','shift'=>'shifts','year'=>'years'];
    $type = $input['type'] ?? '';
    if (!is_string($type) || !isset($tables[$type])) {
        fail('Catálogo inválido.');
    }
    $name = normalizedName(required($input['name'] ?? null,'Nombre'));
    if ($type === 'year' && !preg_match('/^20\d{2}$/D',$name)) {
        fail('La gestión debe ser un año entre 2000 y 2099.');
    }
    return $db->transaction(function () use ($db,$actor,$tables,$type,$name) {
        if ($type === 'career') {
            $db->rows('SELECT id FROM careers ORDER BY id FOR UPDATE');
            assertCareerName($db,$name);
        }
        $db->run('INSERT INTO ' . $tables[$type] . '(name) VALUES (?)',[$name]);
        $id = (int) $db->pdo->lastInsertId();
        $db->audit($actor,$type === 'career' ? 'Carrera creada' : 'Catálogo actualizado',$name);
        return $type === 'career' ? ['ok'=>true,'career_id'=>$id] : ['ok'=>true];
    });
}

function createUser(Database $db, int $actor, array $input): array
{
    $role = $input['role'] ?? null;
    if (!in_array($role,['student','teacher'],true)) {
        fail('Rol inválido.');
    }
    $ci = $role === 'student' && trim((string)($input['ci'] ?? '')) === '' ? null : required($input['ci'] ?? null,'CI');
    $name = upper(required($input['name'] ?? null,'Nombre'));
    if ($ci !== null && mb_strlen($ci) < 5) {
        fail('El CI debe tener al menos 5 caracteres.');
    }
    return $db->transaction(function () use ($db,$actor,$input,$role,$ci,$name) {
        $db->run('INSERT INTO users(ci,name,role,password) VALUES (?,?,?,?)',[$ci,$name,$role,$ci !== null ? hashCeicomPassword($ci) : null]);
        if ($role === 'student') {
            $db->run('INSERT INTO students(user_id,career_id,shift_id,admission_year_id,level,name_pending) VALUES (?,?,?,?,?,?)',[
                (int)$db->pdo->lastInsertId(),positiveId($input['career_id'] ?? null),positiveId($input['shift_id'] ?? null),
                positiveId($input['admission_year_id'] ?? null),positiveId($input['level'] ?? null),(int)acceptsTrue($input['name_pending'] ?? null),
            ]);
        }
        $db->audit($actor,'Usuario creado',$name);
        return ['ok'=>true];
    });
}

function createOffering(Database $db, int $actor, array $input): array
{
    $teacher = positiveId($input['teacher_id'] ?? null);
    $subject = positiveId($input['subject_id'] ?? null);
    $career = positiveId($input['career_id'] ?? null);
    return $db->transaction(function () use ($db,$actor,$input,$teacher,$subject,$career) {
        if (!$db->first("SELECT id FROM users WHERE id=? AND role='teacher' FOR UPDATE",[$teacher])) {
            fail('Docente inválido.');
        }
        $record = $db->first('SELECT career_id,active FROM subjects WHERE id=? FOR UPDATE',[$subject]);
        if (!$record || $record['career_id'] !== $career) {
            fail('La materia debe pertenecer a la carrera seleccionada.');
        }
        if (!$record['active']) {
            fail('La materia está inactiva. Habilítala en el catálogo para asignarla.');
        }
        $db->run('INSERT INTO offerings(subject_id,module_id,shift_id,teacher_id) VALUES (?,?,?,?)',[
            $subject,positiveId($input['module_id'] ?? null),positiveId($input['shift_id'] ?? null),$teacher,
        ]);
        $db->audit($actor,'Asignación docente creada',"Docente $teacher · carrera $career · materia $subject");
        return ['ok'=>true];
    });
}

function unlockOffering(Database $db, int $actor, array $input): array
{
    $id = positiveId($input['offering_id'] ?? null);
    $hours = positiveId($input['hours'] ?? null);
    $reason = required($input['reason'] ?? null,'Motivo');
    if ($hours > 168) {
        fail('La reapertura admite un máximo de 168 horas.');
    }
    return $db->transaction(function () use ($db,$actor,$id,$hours,$reason) {
        if (!$db->first('SELECT id FROM offerings WHERE id=? FOR UPDATE',[$id])) {
            fail('Materia no encontrada.',404);
        }
        $until = gmdate('Y-m-d H:i:s',time() + $hours * 3600);
        $db->run('UPDATE offerings SET unlocked_until=? WHERE id=?',[$until,$id]);
        $db->audit($actor,'Plazo reabierto',"Asignación $id hasta $until UTC. $reason");
        return ['ok'=>true];
    });
}

function academicLevel(mixed $value): int
{
    $level = positiveId($value);
    if ($level > 3) {
        fail('El año debe estar entre 1 y 3.');
    }
    return $level;
}

function saveSubjects(Database $db, int $actor, array $input): array
{
    $name = upper(required($input['name'] ?? null,'Materia'));
    $level = academicLevel($input['level'] ?? null);
    $code = is_string($input['code'] ?? null) ? strtoupper(trim($input['code'])) : '';
    $code = $code === '' ? null : $code;
    if ($code !== null && !preg_match('~^[A-Z0-9][A-Z0-9._/-]{0,39}$~D',$code)) {
        fail('Código inválido (máximo 40 letras, números, guion, punto o barra).');
    }
    $active = !array_key_exists('active',$input) || acceptsTrue($input['active']);
    $id = empty($input['id']) ? null : positiveId($input['id']);
    $raw = $id !== null || !array_key_exists('career_ids',$input) ? [$input['career_id'] ?? null] : $input['career_ids'];
    if (!is_array($raw) || !$raw) {
        fail('Selecciona al menos una carrera.');
    }
    $careers = array_map('positiveId',$raw);
    if (count($careers) !== count(array_unique($careers))) {
        fail('Selecciona al menos una carrera, sin repetir opciones.');
    }
    sort($careers,SORT_NUMERIC);
    return $db->transaction(function () use ($db,$actor,$name,$level,$code,$active,$id,$careers) {
        $result = ['ok'=>true,'created'=>0,'existing'=>0,'subject_ids'=>[]];
        foreach ($careers as $careerId) {
            if (!$db->first('SELECT id FROM careers WHERE id=? FOR UPDATE',[$careerId])) {
                fail('Una de las carreras seleccionadas no existe.');
            }
            if ($id !== null) {
                $old = $db->first('SELECT * FROM subjects WHERE id=? FOR UPDATE',[$id]);
                if (!$old) {
                    fail('Materia no encontrada.',404);
                }
                if (($old['career_id'] !== $careerId || $old['level'] !== $level) &&
                    $db->first('SELECT id FROM offerings WHERE subject_id=? LIMIT 1',[$id])) {
                    fail('La materia tiene asignaciones. Conserva su carrera y año.');
                }
                $db->run('UPDATE subjects SET name=?,code=?,career_id=?,level=?,active=? WHERE id=?',[$name,$code,$careerId,$level,$active,$id]);
                $db->audit($actor,'Materia actualizada',"$id · $name");
                continue;
            }
            $matches = array_values(array_filter(
                $db->rows('SELECT id,name,code FROM subjects WHERE career_id=? AND level=? FOR UPDATE',[$careerId,$level]),
                static fn($row) => normalizedName($row['name']) === normalizedName($name) || ($code !== null && strtoupper($row['code'] ?? '') === $code)
            ));
            if ($matches) {
                if (count($matches) !== 1 || normalizedName($matches[0]['name']) !== normalizedName($name) || $matches[0]['code'] !== $code) {
                    fail('La materia o el código ya existe con otros datos. Revisa el catálogo.');
                }
                $result['existing']++;
                $result['subject_ids'][] = $matches[0]['id'];
                continue;
            }
            $db->run('INSERT INTO subjects(name,career_id,level,code,active) VALUES (?,?,?,?,?)',[$name,$careerId,$level,$code,$active]);
            $result['created']++;
            $result['subject_ids'][] = (int)$db->pdo->lastInsertId();
            $db->audit($actor,'Materia creada',"$name · carrera $careerId · $level"."º año");
        }
        return $result;
    });
}

function calendarDate(mixed $value): string
{
    if (!is_string($value) || !preg_match('/^(\d{4})-(\d{2})-(\d{2})$/D',$value,$parts)
        || !checkdate((int)$parts[2],(int)$parts[3],(int)$parts[1])) {
        fail('Fecha inválida.');
    }
    return $value;
}

function saveModule(Database $db, int $actor, array $input, ?int $id): array
{
    $name = normalizedName(required($input['name'] ?? null,'Nombre'));
    $yearId = positiveId($input['year_id'] ?? null);
    $start = calendarDate($input['start_date'] ?? null);
    $end = calendarDate($input['end_date'] ?? null);
    if ($start > $end) {
        fail('La fecha final debe ser posterior al inicio.');
    }
    return $db->transaction(function () use ($db,$actor,$input,$id,$name,$yearId,$start,$end) {
        $year = $db->first('SELECT name FROM years WHERE id=? FOR UPDATE',[$yearId]);
        if (!$year || substr($start,0,4) !== $year['name'] || substr($end,0,4) !== $year['name']) {
            fail('Las fechas deben pertenecer a la gestión cursada.');
        }
        $old = $id === null ? null : $db->first('SELECT * FROM modules WHERE id=? FOR UPDATE',[$id]);
        if ($id !== null && !$old) {
            fail('Trimestre no encontrado.',404);
        }
        $raw = array_key_exists('admission_year_id',$input) ? $input['admission_year_id'] : ($old['admission_year_id'] ?? null);
        $scope = $raw === null || $raw === '' ? null : positiveId($raw);
        if ($scope !== null) {
            $admission = $db->first('SELECT name FROM years WHERE id=?',[$scope]);
            if (!$admission || $admission['name'] > $year['name']) {
                fail('El ingreso debe estar registrado y no ser posterior a la gestión cursada.');
            }
        }
        if ($old && ($old['year_id'] !== $yearId || $old['admission_year_id'] !== $scope) &&
            $db->first('SELECT id FROM offerings WHERE module_id=? LIMIT 1',[$id])) {
            fail('El trimestre tiene asignaciones. Conserva su gestión y calendario de ingreso.',409);
        }
        $peers = $db->rows('SELECT name,start_date,end_date FROM modules WHERE year_id=? AND admission_year_id <=> ? AND id<>? FOR UPDATE',[$yearId,$scope,$id ?? 0]);
        if (count($peers) >= 4) {
            fail('El calendario ya tiene cuatro módulos en esa gestión.');
        }
        foreach ($peers as $peer) {
            if ($peer['start_date'] <= $end && $peer['end_date'] >= $start) {
                fail('Las fechas coinciden con '.$peer['name'].'. Usa otro calendario de ingreso si corresponde.');
            }
            if (normalizedName($peer['name']) === $name) {
                fail('Ya existe un trimestre con ese nombre en este calendario.',409);
            }
        }
        if ($id === null) {
            $db->run('INSERT INTO modules(name,year_id,admission_year_id,start_date,end_date) VALUES (?,?,?,?,?)',[$name,$yearId,$scope,$start,$end]);
            $id = (int)$db->pdo->lastInsertId();
        } else {
            $db->run('UPDATE modules SET name=?,year_id=?,admission_year_id=?,start_date=?,end_date=? WHERE id=?',[$name,$yearId,$scope,$start,$end,$id]);
        }
        $db->audit($actor,$old ? 'Trimestre editado' : 'Módulo creado',"$name · $start a $end");
        return ['ok'=>true,'module_id'=>$id];
    });
}

function saveStudentProfile(Database $db, int $actor, array $input, bool $editScope): array
{
    $id = positiveId($input['student_id'] ?? null);
    $name = normalizedName(required($input['name'] ?? null,'Nombre'));
    $ci = is_string($input['ci'] ?? null) ? trim($input['ci']) : '';
    $ci = $ci === '' ? null : $ci;
    if ($ci !== null && (mb_strlen($ci) < 5 || mb_strlen($ci) > 40)) {
        fail('El CI debe tener entre 5 y 40 caracteres.');
    }
    return $db->transaction(function () use ($db,$actor,$input,$editScope,$id,$name,$ci) {
        $student = $db->first('SELECT * FROM students WHERE user_id=? FOR UPDATE',[$id]);
        $user = $db->first("SELECT ci FROM users WHERE id=? AND role='student' FOR UPDATE",[$id]);
        if (!$student || !$user) {
            fail('Estudiante no encontrado.',404);
        }
        if ($user['ci'] !== null && $ci === null) {
            fail('No puedes dejar vacío un CI ya registrado.');
        }
        $pending = array_key_exists('name_pending',$input) ? acceptsTrue($input['name_pending']) : (bool)$student['name_pending'];
        if ($ci !== null && $pending) {
            fail('Confirma el nombre completo antes de habilitar el acceso.');
        }
        $db->run('UPDATE users SET name=?,ci=?,password=COALESCE(password,?),must_change=CASE WHEN password IS NULL THEN 1 ELSE must_change END WHERE id=?',
            [$name,$ci,$ci !== null && $user['ci'] === null ? hashCeicomPassword($ci) : null,$id]);
        if ($ci !== $user['ci']) {
            $db->run('DELETE FROM sessions WHERE user_id=?',[$id]);
        }
        $db->run('UPDATE students SET career_id=?,shift_id=?,admission_year_id=?,level=?,name_pending=? WHERE user_id=?',[
            $editScope ? positiveId($input['career_id'] ?? null) : $student['career_id'],
            $editScope ? positiveId($input['shift_id'] ?? null) : $student['shift_id'],
            $editScope ? positiveId($input['admission_year_id'] ?? null) : $student['admission_year_id'],
            $editScope ? academicLevel($input['level'] ?? null) : $student['level'],
            $pending,$id,
        ]);
        $db->audit($actor,'Estudiante editado',"Estudiante $id · $name");
        return ['ok'=>true];
    });
}

function resetPortalPassword(Database $db, int $actor, array $input, string $role): array
{
    $id = positiveId($input[$role.'_id'] ?? null);
    $password = required($input['password'] ?? null,'Contraseña temporal');
    if ($password !== $input['password'] || mb_strlen($password) < 8) {
        fail('La contraseña temporal debe tener entre 8 y 160 caracteres.');
    }
    return $db->transaction(function () use ($db,$actor,$id,$password,$role) {
        $user = $db->first('SELECT ci FROM users WHERE id=? AND role=? FOR UPDATE',[$id,$role]);
        if (!$user || !$user['ci'] || $user['ci'] === $password) {
            fail('La cuenta necesita un CI y una contraseña temporal distinta.');
        }
        $db->run('UPDATE users SET password=?,must_change=1 WHERE id=?',[hashCeicomPassword($password),$id]);
        $db->run('DELETE FROM sessions WHERE user_id=?',[$id]);
        $db->audit($actor,'Contraseña restablecida',"Cuenta $id · $role");
        return ['ok'=>true];
    });
}

function changeStudentStatus(Database $db, int $actor, array $input, string $path): array
{
    $id = positiveId($input['student_id'] ?? null);
    return $db->transaction(function () use ($db,$actor,$input,$id,$path) {
        if (!$db->first('SELECT user_id FROM students WHERE user_id=? FOR UPDATE',[$id])) {
            fail('Estudiante no encontrado.',404);
        }
        if ($path === '/api/transfer') {
            $reason = required($input['reason'] ?? null,'Motivo');
            $db->run('UPDATE students SET shift_id=?,level=? WHERE user_id=?',[positiveId($input['shift_id'] ?? null),academicLevel($input['level'] ?? null),$id]);
            $db->audit($actor,'Traslado / actualización académica',"Estudiante $id · $reason");
        } else {
            $blocked = $input['blocked'] ?? null;
            if (!is_bool($blocked)) {
                fail('Estado inválido.');
            }
            $db->run('UPDATE users SET blocked=? WHERE id=?',[$blocked,$id]);
            $db->audit($actor,$blocked ? 'Consulta suspendida' : 'Consulta habilitada',"Estudiante $id");
        }
        return ['ok'=>true];
    });
}

function saveRegisteredGroup(Database $db, int $actor, array $input): array
{
    $raw = $input['student_ids'] ?? null;
    if (!is_array($raw) || !$raw || count($raw) > 1000) {
        fail('Selecciona de 1 a 1000 estudiantes registrados.');
    }
    $ids = array_map('positiveId',$raw);
    if (count($ids) !== count(array_unique($ids))) {
        fail('Hay estudiantes repetidos en la selección.');
    }
    sort($ids,SORT_NUMERIC);
    $career = positiveId($input['career_id'] ?? null);
    $level = academicLevel($input['level'] ?? null);
    $subjectId = positiveId($input['subject_id'] ?? null);
    $shift = positiveId($input['shift_id'] ?? null);
    $admission = positiveId($input['admission_year_id'] ?? null);
    $year = positiveId($input['year_id'] ?? null);
    $moduleId = positiveId($input['module_id'] ?? null);
    $teacher = positiveId($input['teacher_id'] ?? null);
    $allowRetake = acceptsTrue($input['allow_retake'] ?? null);

    return $db->transaction(function () use ($db,$actor,$ids,$career,$level,$subjectId,$shift,$admission,$year,$moduleId,$teacher,$allowRetake) {
        $module = $db->first('SELECT * FROM modules WHERE id=? FOR UPDATE',[$moduleId]);
        if (!$module || $module['year_id'] !== $year) {
            fail('El trimestre debe pertenecer a la gestión cursada.');
        }
        $subject = $db->first('SELECT * FROM subjects WHERE id=? FOR UPDATE',[$subjectId]);
        if (!$subject || !$subject['active'] || $subject['career_id'] !== $career || $subject['level'] !== $level) {
            fail('La materia debe estar activa y corresponder a la carrera y año seleccionados.');
        }
        $validYear = $db->first('SELECT a.id FROM years a JOIN years y ON y.id=? WHERE a.id=? AND a.name<=y.name',[$year,$admission]);
        if (!$validYear) {
            fail('La gestión de ingreso no puede ser posterior a la cursada.');
        }
        if (!$db->first("SELECT id FROM users WHERE id=? AND role='teacher' FOR UPDATE",[$teacher])) {
            fail('Selecciona un docente registrado.');
        }
        $offering = $db->first('SELECT id,teacher_id FROM offerings WHERE subject_id=? AND module_id=? AND shift_id=? FOR UPDATE',[$subjectId,$moduleId,$shift]);
        if ($offering && $offering['teacher_id'] !== $teacher) {
            fail('La materia ya está asignada a otro docente en ese trimestre y turno.',409);
        }
        if (!$offering) {
            $db->run('INSERT INTO offerings(subject_id,module_id,shift_id,teacher_id) VALUES (?,?,?,?)',[$subjectId,$moduleId,$shift,$teacher]);
            $offering = ['id'=>(int)$db->pdo->lastInsertId()];
        }
        $placeholders = implode(',',array_fill(0,count($ids),'?'));
        $students = $db->rows("SELECT * FROM students WHERE user_id IN ($placeholders) ORDER BY user_id FOR UPDATE",$ids);
        if (count($students) !== count($ids)) {
            fail('Todos los estudiantes deben estar registrados.');
        }
        $hasRegular = false;
        foreach ($students as $student) {
            if ($student['career_id'] !== $career || $student['shift_id'] !== $shift || $student['admission_year_id'] !== $admission ||
                $student['level'] < $level || ($student['level'] > $level && !$allowRetake)) {
                fail('La selección contiene estudiantes de otra carrera, año, ingreso o turno.');
            }
            $hasRegular = $hasRegular || $student['level'] === $level;
        }
        $group = $db->first('SELECT id,admission_year_id FROM academic_groups WHERE offering_id=? FOR UPDATE',[$offering['id']]);
        if ($hasRegular && $group && $group['admission_year_id'] !== $admission) {
            fail('Esta asignación ya está vinculada a otro ingreso.',409);
        }
        if ($hasRegular && !calendarAcceptsAdmission($db,$module,$admission)) {
            fail('Este módulo pertenece a otro calendario de ingreso.');
        }
        if (!$group) {
            $db->run('INSERT INTO academic_groups(subject_id,year_id,admission_year_id,shift_id,offering_id) VALUES (?,?,?,?,?)',
                [$subjectId,$year,$admission,$shift,$offering['id']]);
            $group = ['id'=>(int)$db->pdo->lastInsertId()];
        }
        $count = 0;
        foreach ($students as $student) {
            $studentId = $student['user_id'];
            if (!$db->first('SELECT id FROM enrollments WHERE student_id=? AND offering_id=?',[$studentId,$offering['id']])) {
                $db->run('INSERT INTO enrollments(student_id,offering_id,is_retake) VALUES (?,?,?)',[$studentId,$offering['id'],$student['level'] > $level]);
                $count++;
            }
        }
        $db->run('INSERT INTO academic_group_students(group_id,student_id) SELECT ?,e.student_id FROM enrollments e WHERE e.offering_id=?
            ON DUPLICATE KEY UPDATE student_id=VALUES(student_id)',[$group['id'],$offering['id']]);
        $db->audit($actor,'Grupo de estudiantes registrados guardado',"Grupo {$group['id']} · $count inscripciones nuevas");
        return ['ok'=>true,'group_id'=>$group['id'],'offering_id'=>$offering['id'],'enrollments_created'=>$count,'students_created'=>0];
    });
}

function calendarAcceptsAdmission(Database $db, array $module, int $admission): bool
{
    if ($module['admission_year_id'] !== null) {
        return $module['admission_year_id'] === $admission;
    }
    return !$db->first('SELECT id FROM modules WHERE year_id=? AND admission_year_id=? AND start_date<=? AND end_date>=? LIMIT 1',
        [$module['year_id'],$admission,$module['end_date'],$module['start_date']]);
}
