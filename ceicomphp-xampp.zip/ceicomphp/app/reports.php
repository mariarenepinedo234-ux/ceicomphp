<?php

declare(strict_types=1);

use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

function reportData(Database $db, int $id): array
{
    return $db->transaction(function () use ($db,$id) {
        $offering = $db->first(<<<'SQL'
SELECT o.*,s.name subject,s.code subject_code,s.level,
  COALESCE((SELECT cn.name FROM career_names cn WHERE cn.career_id=c.id AND cn.year_id=m.year_id),c.name) career,
  m.name module,m.start_date,m.end_date,y.name AS `year`,sh.name shift,u.name teacher
FROM offerings o JOIN subjects s ON s.id=o.subject_id JOIN careers c ON c.id=s.career_id
JOIN modules m ON m.id=o.module_id JOIN years y ON y.id=m.year_id
JOIN shifts sh ON sh.id=o.shift_id JOIN users u ON u.id=o.teacher_id WHERE o.id=?
SQL, [$id]);
        if (!$offering) {
            fail('Materia no encontrada.',404);
        }
        $rows = $db->rows(<<<'SQL'
SELECT e.id,u.name student,u.ci,e.saber,e.hacer,e.ser,e.grade,e.is_retake,s.level student_level,y.name admission_year
FROM enrollments e JOIN users u ON u.id=e.student_id JOIN students s ON s.user_id=e.student_id
JOIN years y ON y.id=s.admission_year_id WHERE e.offering_id=?
ORDER BY CONVERT(u.name USING utf8mb4) COLLATE utf8mb4_spanish_ci,u.ci,e.id
SQL, [$id]);
        $pending = $legacy = $review = 0;
        foreach ($rows as $index => &$row) {
            $grade = $row['grade'];
            $row['number'] = $index + 1;
            $row['status'] = $grade === null ? 'PENDIENTE' : ($grade >= 61 ? 'APROBADO' : 'REPROBADO');
            $pending += (int) ($grade === null);
            $legacy += (int) ($grade !== null && in_array(null,[$row['saber'],$row['hacer'],$row['ser']],true));
            $review += (int) ($row['saber'] > 40 || $row['hacer'] > 40 || $row['ser'] > 20);
            $row = formatAcademicRow($row);
        }
        unset($row);
        $offering['course'] = [1=>'PRIMERO',2=>'SEGUNDO',3=>'TERCERO'][$offering['level']];
        return [
            'offering'=>partRow($offering),'rows'=>$rows,'pending'=>$pending,'legacy'=>$legacy,
            'needs_review'=>$review,'generated_at'=>gmdate('Y-m-d\TH:i:s\Z'),
        ];
    });
}

function reportStudent(array $row): string
{
    return $row['student'] . ($row['is_retake']
        ? "\nMATERIA PENDIENTE · {$row['student_level']}º AÑO ACTUAL · INGRESO {$row['admission_year']}"
        : '');
}

function pdfText(string $text): string
{
    return mb_convert_encoding($text,'Windows-1252','UTF-8');
}

function reportDate(string $iso): string
{
    $date = (new DateTimeImmutable($iso))->setTimezone(new DateTimeZone('America/La_Paz'));
    $months = [1=>'enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
    return upper('Elaborado el '.$date->format('j').' de '.$months[(int)$date->format('n')].' de '.$date->format('Y'));
}

function renderReportPdf(array $report, string $logo): string
{
    $pdf = new FPDF('P','pt','Letter');
    $pdf->SetAutoPageBreak(false);
    $pdf->SetTitle(pdfText('Planilla de notas · Ceicom'));
    $pdf->SetAuthor(pdfText('Instituto Tecnológico Ceicom'));
    $o = $report['offering'];
    $widths = [27,244,47,47,47,48,68];
    $x = [42];
    foreach ($widths as $width) {
        $x[] = end($x)+$width;
    }
    $pages = [];
    $chunk = [];
    $height = 0;
    $pdf->SetFont('Helvetica','',7.5);
    foreach ($report['rows'] as $row) {
        $lines = explode("\n",pdfText(reportStudent($row)));
        $count = array_sum(array_map(static fn($line) => max(1,ceil($pdf->GetStringWidth($line)/232)),$lines));
        $row['height'] = (int)max(18,$count*9+8);
        if ($chunk && (count($chunk)===20 || $height+$row['height']>360)) {
            $pages[] = $chunk;
            $chunk = [];
            $height = 0;
        }
        $chunk[] = $row;
        $height += $row['height'];
    }
    if ($chunk) {
        $pages[] = $chunk;
    }
    $ink = [48,42,48];
    $wine = [114,40,63];
    $light = [143,128,137];
    $blue = [231,240,243];
    $text = static function (float $left,float $top,float $width,string $value,float $size=8,string $style='',string $align='L',array $color=[48,42,48]) use ($pdf): void {
        $pdf->SetTextColor(...$color);
        $pdf->SetFont('Helvetica',$style,$size);
        $pdf->SetXY($left,$top);
        $pdf->MultiCell($width,$size+1,pdfText($value),0,$align);
    };
    $cell = static function (float $left,float $top,float $width,float $height,string $value,array $fill,string $font='B',float $size=7,string $align='C',array $color=[48,42,48]) use ($pdf,$text): void {
        $pdf->SetDrawColor(189,179,184);
        $pdf->SetFillColor(...$fill);
        $pdf->Rect($left,$top,$width,$height,'DF');
        $pdf->SetFont('Helvetica',$font,$size);
        $lines = explode("\n",pdfText($value));
        $count = array_sum(array_map(static fn($line) => max(1,ceil($pdf->GetStringWidth($line)/($width-8))),$lines));
        $text($left+3,$top+max(3,($height-$count*($size+1))/2),$width-6,$value,$size,$font,$align,$color);
    };
    foreach ($pages as $index => $rows) {
        $pdf->AddPage();
        $pdf->Image($logo,43,23,64);
        $text(310,36,260,'INSTITUTO TECNOLÓGICO',8,'','R');
        $text(310,50,260,'CEICOM',23,'B','R',$wine);
        $text(310,78,260,$o['year'],12,'','R');
        $pdf->SetDrawColor(216,199,207);
        $pdf->Line(42,104,570,104);
        $text(42,116,528,'PLANILLA DE NOTAS',16,'B','C',$wine);
        $text(42,137,528,reportDate($report['generated_at']),8,'I','C',$light);
        if ($report['draft']) {
            $text(42,149,528,'BORRADOR · NOTAS PENDIENTES / DOCUMENTO PARA REVISIÓN',7,'B','C',[150,117,63]);
        }
        foreach ([
            [43,160,'CARRERA:',$o['career'],108,450],
            [43,186,'MATERIA:',$o['subject'].($o['subject_code'] ? ' ('.$o['subject_code'].')' : ''),108,450],
            [43,204,'CURSO:',$o['course'],108,130],
            [270,204,'TURNO:',$o['shift'],315,245],
            [43,220,'PERÍODO:',"{$o['module']} · GESTIÓN {$o['year']}",108,450],
        ] as [$left,$top,$label,$value,$valueX,$width]) {
            $text($left,$top,65,$label,8,'B');
            $text($valueX,$top,$width,$value);
        }
        $y = 241;
        $cell($x[0],$y,$widths[0],48,'Nº',$blue);
        $cell($x[1],$y,$widths[1],48,'APELLIDOS Y NOMBRES',$blue);
        $cell($x[2],$y,141,17,'DIMENSIONES',[245,236,221]);
        foreach (["SABER\n40 PTS","HACER\n40 PTS","SER\n20 PTS"] as $offset=>$label) {
            $cell($x[$offset+2],$y+17,47,31,$label,$offset===0 ? [248,238,227] : $blue);
        }
        $cell($x[5],$y,$widths[5],48,$o['series_id'] ? "NOTA\nPARTE" : "NOTA\nFINAL",$blue);
        $cell($x[6],$y,$widths[6],48,'OBSERVACIÓN',$blue);
        $y += 48;
        foreach ($rows as $row) {
            $failed = $row['grade'] !== null && $row['grade'] < 61;
            $colors = [2=>[252,245,237],3=>[240,246,248],4=>[240,246,248]];
            $values = [$row['number'],reportStudent($row),$row['saber'],$row['hacer'],$row['ser'],$row['grade'],$row['status']];
            foreach ($values as $i=>$value) {
                $cell($x[$i],$y,$widths[$i],$row['height'],(string)($value ?? '—'),
                    $failed ? [251,232,235] : ($colors[$i] ?? [255,255,255]),
                    $i===1 ? '' : 'B',$i===6 ? 6.5 : 7.5,$i===1 ? 'L' : 'C',$failed ? [178,39,64] : $ink);
            }
            $y += $row['height'];
        }
        $last = end($rows)['number'];
        for ($i=count($rows);$i<20 && $y+18<=650;$i++) {
            foreach ($widths as $col=>$width) {
                $cell($x[$col],$y,$width,18,$col===0 ? (string)++$last : '',[255,255,255],'');
            }
            $y += 18;
        }
        $text(43,max($y+11,661),528,'ESCALA: 1 A 100 PUNTOS · APROBACIÓN DESDE 61 · ROJO: ESTUDIANTE REPROBADO',7,'','L',$light);
        if ($report['legacy']) {
            $text(43,676,528,'—: DESGLOSE NO REGISTRADO EN NOTAS ANTERIORES. LA NOTA FINAL ORIGINAL SE CONSERVA.',6.5,'','L',$light);
        }
        $pdf->SetDrawColor(...$ink);
        $pdf->Line(49,717,267,717);
        $pdf->Line(345,717,563,717);
        $text(49,725,218,$o['teacher'],8,'B','C');
        $text(49,740,218,'DOCENTE',7,'','C');
        $text(345,740,218,'DIRECCIÓN ACADÉMICA',8,'B','C');
        $text(43,760,390,'CEICOM · REGISTRO ACADÉMICO · PLANILLA '.$o['id'],7,'','L',$light);
        $text(450,760,120,'PÁGINA '.($index+1).' DE '.count($pages),7,'','R',$light);
    }
    return $pdf->Output('S');
}

function renderReportExcel(array $report, string $logo): string
{
    $book = new Spreadsheet();
    $sheet = $book->getActiveSheet();
    $sheet->setTitle('PLANILLA DE NOTAS');
    $sheet->setShowGridlines(false);
    $sheet->freezePane('A15');
    $o = $report['offering'];
    $book->getDefaultStyle()->getFont()->setName('Times New Roman')->setSize(9);
    $drawing = new Drawing();
    $drawing->setPath($logo)->setCoordinates('B1')->setHeight(100)->setWorksheet($sheet);
    foreach (['A'=>2,'B'=>4,'C'=>12,'D'=>14,'E'=>14,'F'=>9,'G'=>9,'H'=>9,'I'=>9,'J'=>17] as $column=>$width) {
        $sheet->getColumnDimension($column)->setWidth($width);
    }
    $merge = static function (string $range, string $value, int $size = 10, bool $bold = false, string $align = 'left') use ($sheet): void {
        $sheet->mergeCells($range)->setCellValueExplicit(explode(':',$range)[0],upper($value),DataType::TYPE_STRING);
        $style = $sheet->getStyle($range);
        $style->getFont()->setSize($size)->setBold($bold)->getColor()->setRGB('302A30');
        $style->getAlignment()->setHorizontal($align)->setVertical('center')->setWrapText(true);
    };
    $merge('F3:J3','INSTITUTO TECNOLÓGICO',11,true,'right');
    $merge('H4:J4','CEICOM',18,true,'center');
    $merge('H5:J5',$o['year'],14,true,'center');
    if ($report['draft']) {
        $merge('F6:J6','BORRADOR · PARA REVISIÓN',9,true,'right');
    }
    $merge('A7:J7','PLANILLA DE NOTAS',16,true,'center');
    $merge('D8:J8',reportDate($report['generated_at']),10,false,'center');
    $merge('B9:C9','CARRERA:',10,true);
    $merge('D9:J9',$o['career']);
    $merge('B10:C10','MATERIA:',10,true);
    $merge('D10:J10',$o['subject'].($o['subject_code'] ? ' ('.$o['subject_code'].')' : ''));
    $merge('B11:C11','CURSO:',10,true);
    $merge('D11:E11',$o['course']);
    $merge('F11:J11',"{$o['module']} · {$o['year']} · {$o['shift']}",8,false,'right');
    foreach ([7=>23,8=>19,9=>27,10=>28,11=>20,12=>17,13=>45,14=>18] as $row=>$height) {
        $sheet->getRowDimension($row)->setRowHeight($height);
    }
    $merge('B12:B14','Nº',10,true,'center');
    $merge('C12:E14','APELLIDOS Y NOMBRES',10,true,'center');
    $merge('F12:H12','DIMENSIONES',10,true,'center');
    $merge('I12:I14',$o['series_id'] ? 'NOTA DE LA PARTE' : 'NOTA FINAL',9,true,'center');
    $merge('J12:J14','OBSERVACIONES',9,true,'center');
    $sheet->getStyle('B12:J14')->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('DAEEF3');
    $sheet->getStyle('F12:H12')->getFill()->getStartColor()->setRGB('FFF2B3');
    $sheet->getStyle('B12:J14')->getAlignment()->setHorizontal('center')->setVertical('center')->setWrapText(true);
    $dimensions = ['F'=>['saber',40],'G'=>['hacer',40],'H'=>['ser',20]];
    foreach ($dimensions as $column=>[$key,$max]) {
        $sheet->setCellValue($column.'13',upper($key));
        $sheet->getStyle($column.'13')->getAlignment()->setTextRotation(90);
        $sheet->setCellValue($column.'14',"$max PTS");
    }
    $count = max(20,count($report['rows']));
    for ($offset=0;$offset<$count;$offset++) {
        $line = 15+$offset;
        $row = $report['rows'][$offset] ?? null;
        $sheet->mergeCells("C$line:E$line")->setCellValue("B$line",$offset+1);
        if ($row) {
            $student = reportStudent($row);
            $sheet->setCellValueExplicit("C$line",$student,DataType::TYPE_STRING);
            $sheet->getRowDimension($line)->setRowHeight(max(16,ceil(mb_strlen($student)/45)*11+5));
            $total = !in_array(null,[$row['saber'],$row['hacer'],$row['ser']],true)
                ? '=IF(COUNT(F'.$line.':H'.$line.')=3,ROUND(SUM(F'.$line.':H'.$line.'),2),"")'
                : $row['grade'];
            $sheet->setCellValue("I$line",$total);
            $sheet->setCellValue("J$line",'=IF(ISNUMBER(I'.$line.'),IF(I'.$line.'>=61,"APROBADO","REPROBADO"),"PENDIENTE")');
        }
        foreach ($dimensions as $column=>[$key,$max]) {
            $cell = $column.$line;
            $sheet->setCellValue($cell,$row[$key] ?? null);
            $sheet->getStyle($cell)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB(['F'=>'FCE9D9','G'=>'DAEEF3','H'=>'E4DFEC'][$column]);
            $validation = $sheet->getCell($cell)->getDataValidation();
            $validation->setType('decimal')->setOperator('between')->setAllowBlank(true)
                ->setShowErrorMessage(true)->setErrorTitle('Nota fuera de rango')->setError("Ingresa de 0 a $max puntos.")
                ->setFormula1('0')->setFormula2((string)$max);
        }
        if (($offset+1)%20===0 && $offset+1<$count) {
            $sheet->setBreak('A'.($line+1), \PhpOffice\PhpSpreadsheet\Worksheet\Worksheet::BREAK_ROW);
        }
    }
    $last = 14+$count;
    $sheet->getStyle("B15:J$last")->getAlignment()->setHorizontal('center')->setVertical('center')->setWrapText(true);
    $sheet->getStyle("C15:E$last")->getAlignment()->setHorizontal('left');
    $sheet->getStyle("F15:I$last")->getNumberFormat()->setFormatCode('0.##');
    $sheet->getStyle("B12:J$last")->getBorders()->getAllBorders()->setBorderStyle('thin')->getColor()->setRGB('858085');
    $failed = new \PhpOffice\PhpSpreadsheet\Style\Conditional();
    $failed->setConditionType('expression')->addCondition('AND(ISNUMBER($I15),$I15<61)');
    $failed->getStyle()->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('FBE8EB');
    $failed->getStyle()->getFont()->getColor()->setRGB('B22740');
    $sheet->getStyle("B15:J$last")->setConditionalStyles([$failed]);
    $note = $last+2;
    $merge("B$note:J$note",'Escala 1–100 · Aprobación desde 61 · Rojo: estudiante reprobado.',8);
    $note++;
    $merge("B$note:J$note",$report['legacy'] ? '—: nota anterior sin desglose; se conserva su total original.' :
        'Excel editable: cambiar puntajes recalcula la nota final. No modifica el portal.',8);
    $signature = $last+6;
    $merge("B$signature:E$signature",$o['teacher'],9,true,'center');
    $merge("G$signature:J$signature",'FIRMA DIRECCIÓN ACADÉMICA',9,true,'center');
    $sheet->getPageSetup()->setPaperSize(1)->setFitToWidth(1)->setFitToHeight(0)
        ->setHorizontalCentered(true)->setRowsToRepeatAtTopByStartAndEnd(1,14)->setPrintArea('A1:J'.($signature+1));
    $sheet->getHeaderFooter()->setOddFooter(($report['draft'] ? '&LBORRADOR · REGISTRO ACADÉMICO' : '&LCEICOM · REGISTRO ACADÉMICO').'&RPÁGINA &P DE &N');
    $file = tempnam(sys_get_temp_dir(),'ceicom-xlsx-');
    try {
        (new Xlsx($book))->save($file);
        return file_get_contents($file);
    } finally {
        unlink($file);
        $book->disconnectWorksheets();
    }
}

function sendReport(Database $db, array $user, int $id): never
{
    if (!in_array($user['role'],['admin','teacher'],true)) {
        fail('Acceso restringido.',403);
    }
    $report = reportData($db,$id);
    $o = $report['offering'];
    if ($user['role'] === 'teacher' && $o['teacher_id'] !== $user['id']) {
        fail('No tienes esta materia asignada.',403);
    }
    $format = $_GET['format'] ?? 'json';
    if ($format === 'json') {
        jsonResponse($report);
    }
    if (!in_array($format,['pdf','xlsx'],true)) {
        fail('Formato no disponible.');
    }
    $draft = ($_GET['draft'] ?? '') === 'true';
    if (!$report['rows'] || ($report['pending'] && !$draft)) {
        fail('Completa y guarda las notas finales de todos los estudiantes antes de exportar la planilla.',409);
    }
    if ($report['needs_review']) {
        fail('Hay notas de una escala anterior fuera de los límites actuales (40/40/20). Revísalas antes de exportar.',409);
    }
    if (!is_file(__DIR__.'/vendor/autoload.php')) {
        fail('Faltan las dependencias PHP de exportación.',503);
    }
    require_once __DIR__.'/vendor/autoload.php';
    $report['draft'] = $draft;
    $logo = $_SERVER['DOCUMENT_ROOT'].'/assets/ceicom-logo.png';
    if (!is_file($logo)) {
        $logo = dirname(__DIR__).'/assets/ceicom-logo.png';
    }
    $file = $format === 'pdf' ? renderReportPdf($report,$logo) : renderReportExcel($report,$logo);
    $db->audit($user['id'],$draft ? 'Borrador de planilla exportado' : 'Planilla exportada',$o['subject'].' · '.$o['career'].' · '.strtoupper($format));
    $name = preg_replace('/[^a-z0-9-]+/i','-',iconv('UTF-8','ASCII//TRANSLIT',"planilla-{$o['career']}-{$o['subject']}-{$o['year']}-{$o['module']}-{$o['shift']}"));
    $filename = ($draft ? 'borrador-' : '').substr($name,0,170).'.'.$format;
    header('Content-Type: '.($format === 'pdf' ? 'application/pdf' : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'));
    header('Content-Disposition: attachment; filename="'.$filename.'"');
    header('Content-Length: '.strlen($file));
    echo $file;
    exit;
}
