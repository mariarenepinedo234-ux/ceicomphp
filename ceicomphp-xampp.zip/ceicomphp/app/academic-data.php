<?php

declare(strict_types=1);

function formatAcademicRow(array $row): array
{
    $names = ['name','student','subject','subject_base','subject_code','career','teacher','shift','module','actor'];
    $timestamps = ['created_at','updated_at','unlocked_until'];
    $flags = ['active','name_pending','blocked','is_retake','part_recovery','series_complete'];
    foreach ($row as $key => $value) {
        if (is_string($value) && in_array($key, $names, true)) {
            $row[$key] = upper($value);
        }
        if (is_string($value) && in_array($key,$timestamps,true)) {
            $row[$key] = (new DateTimeImmutable($value,new DateTimeZone('UTC')))->format('Y-m-d\TH:i:s.v\Z');
        }
        if ($value !== null && in_array($key, $flags, true)) {
            $row[$key] = (bool) $value;
        }
    }
    return $row;
}

function partRow(array $row): array
{
    $row['subject_base'] = $row['subject'];
    if ($row['series_id'] !== null) {
        $number = (int) $row['part_number'];
        $roman = '';
        if ($number > 3999) {
            $roman = (string) $number;
        } else {
            foreach ([1000=>'M',900=>'CM',500=>'D',400=>'CD',100=>'C',90=>'XC',50=>'L',40=>'XL',10=>'X',9=>'IX',5=>'V',4=>'IV',1=>'I'] as $value => $label) {
                $roman .= str_repeat($label, intdiv($number, $value));
                $number %= $value;
            }
        }
        $row['subject'] .= ' · PARTE ' . $roman . ($row['part_recovery'] ? ' · RECUPERACIÓN' : '');
    }
    return formatAcademicRow($row);
}

function academicData(Database $db, array $user): array
{
    if ($user['role'] === 'student' && $user['blocked']) {
        return ['blocked' => true];
    }
    $admin = $user['role'] === 'admin';
    $teacher = $user['role'] === 'teacher';
    $offeringSql = <<<'SQL'
SELECT o.*, s.name subject, s.code subject_code, s.catalog_order, s.career_id, s.level, ps.part_count,ps.completed series_complete, m.admission_year_id module_admission_year_id, ay.name module_admission_year, COALESCE((SELECT cn.name FROM career_names cn WHERE cn.career_id=c.id AND cn.year_id=m.year_id),c.name) career, m.name module, m.start_date, m.end_date, m.year_id, y.name AS `year`, sh.name shift, u.name teacher FROM offerings o JOIN subjects s ON s.id=o.subject_id JOIN careers c ON c.id=s.career_id JOIN modules m ON m.id=o.module_id JOIN years y ON y.id=m.year_id JOIN shifts sh ON sh.id=o.shift_id JOIN users u ON u.id=o.teacher_id LEFT JOIN years ay ON ay.id=m.admission_year_id LEFT JOIN subject_series ps ON ps.id=o.series_id
SQL;
    $enrollmentSql = <<<'SQL'
SELECT e.*,u.name student,u.ci,s.level student_level,y.name admission_year FROM enrollments e JOIN users u ON u.id=e.student_id JOIN students s ON s.user_id=e.student_id JOIN years y ON y.id=s.admission_year_id
SQL;
    $params = $admin ? [] : [$user['id']];
    if ($teacher) {
        $offeringSql .= ' WHERE o.teacher_id=?';
        $enrollmentSql .= ' JOIN offerings o ON o.id=e.offering_id WHERE o.teacher_id=?';
    } elseif (!$admin) {
        $offeringSql .= ' WHERE o.id IN (SELECT offering_id FROM enrollments WHERE student_id=?)';
        $enrollmentSql .= ' WHERE e.student_id=?';
    }
    $data = [
        'offerings' => array_map(static function ($row) {
            $row['deadline'] = deadline($row['end_date'])->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d\TH:i:s.000\Z');
            $row['can_grade'] = canGrade($row['end_date'], $row['unlocked_until']);
            return partRow($row);
        }, $db->rows($offeringSql, $params)),
        'enrollments' => array_map('formatAcademicRow', $db->rows($enrollmentSql, $params)),
        'calendar_admission_year_id' => $user['role'] === 'student'
            ? $db->first('SELECT admission_year_id FROM students WHERE user_id=?', [$user['id']])['admission_year_id'] ?? null
            : null,
    ];
    $shared = [
        'careers' => <<<'SQL'
SELECT * FROM careers
SQL,
        'career_names' => <<<'SQL'
SELECT * FROM career_names ORDER BY career_id,year_id
SQL,
        'shifts' => <<<'SQL'
SELECT * FROM shifts
SQL,
        'years' => <<<'SQL'
SELECT * FROM years ORDER BY name DESC
SQL,
        'modules' => <<<'SQL'
SELECT m.*,y.name AS `year`,ay.name admission_year FROM modules m JOIN years y ON y.id=m.year_id LEFT JOIN years ay ON ay.id=m.admission_year_id ORDER BY start_date
SQL,
    ];
    $adminQueries = [
        'subjects' => <<<'SQL'
SELECT s.*,c.name career FROM subjects s JOIN careers c ON c.id=s.career_id
SQL,
        'students' => <<<'SQL'
SELECT s.*,u.name,u.ci,u.blocked,COALESCE((SELECT cn.name FROM career_names cn WHERE cn.career_id=c.id AND cn.year_id=s.admission_year_id),c.name) career,sh.name shift,y.name admission_year FROM students s JOIN users u ON u.id=s.user_id JOIN careers c ON c.id=s.career_id JOIN shifts sh ON sh.id=s.shift_id JOIN years y ON y.id=s.admission_year_id
SQL,
        'teachers' => <<<'SQL'
SELECT id,name,ci FROM users WHERE role='teacher'
SQL,
        'teacher_directory' => <<<'SQL'
SELECT id,name,user_id FROM teacher_directory ORDER BY name
SQL,
        'group_memberships' => <<<'SQL'
SELECT * FROM academic_group_students ORDER BY group_id,student_id
SQL,
        'academic_groups' => <<<'SQL'
SELECT g.*,o.series_id,o.part_number,o.part_recovery,s.name subject,COALESCE((SELECT cn.name FROM career_names cn WHERE cn.career_id=c.id AND cn.year_id=g.year_id),c.name) career,ay.name admission_year,y.name AS `year`,sh.name shift,o.teacher_id,u.name teacher,m.name module,
            (SELECT COUNT(*) FROM academic_group_students gs WHERE gs.group_id=g.id) student_count,
            (SELECT COUNT(*) FROM enrollments e WHERE e.offering_id=g.offering_id AND e.is_retake) retake_count
            FROM academic_groups g JOIN subjects s ON s.id=g.subject_id JOIN careers c ON c.id=s.career_id
            JOIN years ay ON ay.id=g.admission_year_id JOIN years y ON y.id=g.year_id JOIN shifts sh ON sh.id=g.shift_id
            LEFT JOIN offerings o ON o.id=g.offering_id LEFT JOIN users u ON u.id=o.teacher_id LEFT JOIN modules m ON m.id=o.module_id ORDER BY g.id
SQL,
        'audit' => <<<'SQL'
SELECT a.*,u.name actor FROM audit a LEFT JOIN users u ON u.id=a.actor_id ORDER BY a.id DESC LIMIT 30
SQL,
    ];
    foreach ($shared as $key => $query) {
        $data[$key] = array_map('formatAcademicRow', $db->rows($query));
    }
    foreach ($adminQueries as $key => $query) {
        $data[$key] = $admin ? array_map($key === 'academic_groups' ? 'partRow' : 'formatAcademicRow', $db->rows($query)) : [];
    }
    return $data;
}

function academicHistoryRecords(Database $db, array $user): array
{
    if ($user['role'] !== 'student') {
        fail('Este historial corresponde al perfil estudiante.',403);
    }
    if ($user['blocked']) {
        fail('La consulta de tu expediente está suspendida. Comunícate con secretaría.',403);
    }
    return $db->transaction(function () use ($db,$user) {
        $student = $db->first(<<<'SQL'
SELECT s.user_id,s.level,s.admission_year_id,s.career_id,
 COALESCE((SELECT cn.name FROM career_names cn WHERE cn.career_id=c.id AND cn.year_id=s.admission_year_id),c.name) career,
 sh.name shift,y.name admission_year,u.name
FROM students s JOIN users u ON u.id=s.user_id JOIN careers c ON c.id=s.career_id
JOIN shifts sh ON sh.id=s.shift_id JOIN years y ON y.id=s.admission_year_id WHERE s.user_id=?
SQL,[$user['id']]);
        if (!$student) {
            fail('Estudiante no encontrado.',404);
        }
        $subjects = $db->rows(<<<'SQL'
SELECT s.*,COALESCE((SELECT cn.name FROM career_names cn WHERE cn.career_id=c.id AND cn.year_id=?),c.name) career
FROM subjects s JOIN careers c ON c.id=s.career_id WHERE s.career_id=? AND s.active=true
SQL,[$student['admission_year_id'],$student['career_id']]);
        $attempts = $db->rows(<<<'SQL'
SELECT e.id enrollment_id,e.student_id,e.grade,e.saber,e.hacer,e.ser,e.is_retake,
 o.subject_id,o.series_id,o.part_number,o.part_recovery,ps.part_count,ps.completed series_complete,
 s.name subject,s.code subject_code,s.level,s.career_id,
 COALESCE((SELECT cn.name FROM career_names cn WHERE cn.career_id=c.id AND cn.year_id=m.year_id),c.name) career,
 m.name module,m.start_date,m.end_date,y.name AS `year`,sh.name shift,u.name teacher
FROM enrollments e JOIN offerings o ON o.id=e.offering_id JOIN subjects s ON s.id=o.subject_id
JOIN careers c ON c.id=s.career_id JOIN modules m ON m.id=o.module_id JOIN years y ON y.id=m.year_id
JOIN shifts sh ON sh.id=o.shift_id JOIN users u ON u.id=o.teacher_id LEFT JOIN subject_series ps ON ps.id=o.series_id
WHERE e.student_id=?
SQL,[$user['id']]);
        return [
            'student'=>formatAcademicRow($student),'subjects'=>array_map('formatAcademicRow',$subjects),
            'attempts'=>array_map('partRow',$attempts),
        ];
    });
}
