<?php

declare(strict_types=1);

function nextSubjectPart(Database $db, array $source, ?array $series): array
{
    if ($series) {
        if ($series['completed'] || $source['part_recovery'] || $source['part_number'] !== $series['part_count']) {
            fail('Continúa desde la última parte original de una materia abierta.',409);
        }
        $number = $series['part_count'] + 1;
        $db->run('UPDATE subject_series SET part_count=? WHERE id=?',[$number,$series['id']]);
        return [$series['id'],$number];
    }
    $db->run('INSERT INTO subject_series(subject_id,shift_id,part_count) VALUES (?,?,2)',[$source['subject_id'],$source['shift_id']]);
    $id = (int)$db->pdo->lastInsertId();
    $db->run('UPDATE offerings SET series_id=?,part_number=1 WHERE id=?',[$id,$source['id']]);
    return [$id,2];
}

function subjectPartSource(Database $db, int $id): array
{
    $row = $db->first('SELECT o.*,m.start_date,m.end_date,s.career_id,s.level,s.name subject FROM offerings o
        JOIN modules m ON m.id=o.module_id JOIN subjects s ON s.id=o.subject_id WHERE o.id=? FOR UPDATE',[$id]);
    if (!$row) {
        fail('Asignación no encontrada. Reabre el formulario.',404);
    }
    return $row;
}

function saveSubjectPart(Database $db, int $actor, array $input): array
{
    $sourceId = positiveId($input['offering_id'] ?? null);
    $moduleId = positiveId($input['module_id'] ?? null);
    $teacher = positiveId($input['teacher_id'] ?? null);
    $mode = $input['mode'] ?? '';
    if (!in_array($mode,['continue','recover'],true)) {
        fail('Elige continuar materia o recuperar una parte.');
    }
    $ids = $input['student_ids'] ?? null;
    if (!is_array($ids) || count($ids)>1000) {
        fail('Selecciona hasta 1000 estudiantes registrados.');
    }
    $ids = array_map('positiveId',$ids);
    if (count($ids)!==count(array_unique($ids))) {
        fail('Hay estudiantes repetidos.');
    }
    return $db->transaction(function () use ($db,$actor,$sourceId,$moduleId,$teacher,$mode,$ids) {
        $source = subjectPartSource($db,$sourceId);
        $module = $db->first('SELECT * FROM modules WHERE id=? FOR UPDATE',[$moduleId]);
        if (!$module || $module['start_date'] <= $source['end_date']) {
            fail('Elige un trimestre que comience después de finalizar la parte de origen.');
        }
        if (!$db->first("SELECT id FROM users WHERE id=? AND role='teacher' FOR UPDATE",[$teacher])) {
            fail('Selecciona un docente registrado.');
        }
        if ($db->first('SELECT id FROM offerings WHERE subject_id=? AND module_id=? AND shift_id=? FOR UPDATE',
            [$source['subject_id'],$moduleId,$source['shift_id']])) {
            fail('Ya existe una asignación de esa materia y turno. Elige VINCULAR EXISTENTE para conservar su lista y notas.',409);
        }
        $series = $source['series_id'] ? $db->first('SELECT * FROM subject_series WHERE id=? FOR UPDATE',[$source['series_id']]) : null;
        $recovery = $mode === 'recover';
        if ($recovery && !$series) {
            fail('Esta asignación aún no pertenece a una materia por partes.');
        }
        $studentSql = idsSql($ids);
        $rows = $db->rows("SELECT e.student_id,e.is_retake,s.level,s.career_id,s.shift_id,s.admission_year_id
            FROM enrollments e JOIN students s ON s.user_id=e.student_id
            WHERE e.offering_id=? AND e.student_id IN ($studentSql) ORDER BY e.student_id FOR UPDATE",[$sourceId,...$ids]);
        if (count($rows)!==count($ids)) {
            fail('Solo puedes copiar estudiantes que siguen inscritos en la asignación de origen.',409);
        }
        foreach ($rows as $row) {
            if ($row['career_id']!==$source['career_id'] || $row['shift_id']!==$source['shift_id'] || $row['level']<$source['level']) {
                fail('Un estudiante cambió de carrera, turno o año. Revisa su perfil.');
            }
            if ($row['level']===$source['level'] && !calendarAcceptsAdmission($db,$module,$row['admission_year_id'])) {
                fail('El trimestre elegido no corresponde al calendario de ingreso de todos los estudiantes.');
            }
        }
        [$seriesId,$number] = $recovery ? [$series['id'],$source['part_number']] : nextSubjectPart($db,$source,$series);
        $db->run('INSERT INTO offerings(subject_id,module_id,shift_id,teacher_id,series_id,part_number,part_recovery) VALUES (?,?,?,?,?,?,?)',
            [$source['subject_id'],$moduleId,$source['shift_id'],$teacher,$seriesId,$number,$recovery]);
        $offering = (int)$db->pdo->lastInsertId();
        $cohort = $db->first('SELECT admission_year_id FROM academic_groups WHERE offering_id=?',[$sourceId])['admission_year_id']
            ?? ($rows[0]['admission_year_id'] ?? null);
        $groupId = null;
        if ($cohort !== null) {
            $db->run('INSERT INTO academic_groups(subject_id,year_id,admission_year_id,shift_id,offering_id) VALUES (?,?,?,?,?)',
                [$source['subject_id'],$module['year_id'],$cohort,$source['shift_id'],$offering]);
            $groupId = (int)$db->pdo->lastInsertId();
        }
        foreach ($rows as $row) {
            $db->run('INSERT INTO enrollments(student_id,offering_id,is_retake) VALUES (?,?,?)',
                [$row['student_id'],$offering,$row['is_retake'] || $row['level']>$source['level']]);
            if ($groupId !== null) {
                $db->run('INSERT INTO academic_group_students(group_id,student_id) VALUES (?,?)',[$groupId,$row['student_id']]);
            }
        }
        $db->audit($actor,$recovery ? 'Recuperación de parte creada' : 'Continuación de materia creada',
            "{$source['subject']} · serie $seriesId · parte $number");
        return ['ok'=>true,'offering_id'=>$offering,'series_id'=>$seriesId,'part_number'=>$number,'students'=>count($rows)];
    });
}

function editSeriesStatus(Database $db, int $actor, array $input): array
{
    $id = positiveId($input['series_id'] ?? null);
    $expected = positiveId($input['part_count'] ?? null);
    $completed = $input['completed'] ?? null;
    if (!is_bool($completed)) {
        fail('Indica si la materia queda concluida.');
    }
    return $db->transaction(function () use ($db,$actor,$id,$expected,$completed) {
        $series = $db->first('SELECT part_count FROM subject_series WHERE id=? FOR UPDATE',[$id]);
        if (!$series) {
            fail('Materia por partes no encontrada.',404);
        }
        if ($series['part_count']!==$expected) {
            fail('La cantidad de partes cambió. Reabre el formulario.',409);
        }
        if ($completed && array_column($db->rows('SELECT part_number FROM offerings WHERE series_id=? AND NOT part_recovery ORDER BY part_number',[$id]),
            'part_number')!==range(1,$expected)) {
            fail('Faltan asignaciones de partes.');
        }
        $db->run('UPDATE subject_series SET completed=? WHERE id=?',[$completed,$id]);
        $db->audit($actor,$completed ? 'Materia por partes concluida' : 'Materia por partes reabierta',"Serie $id · $expected partes");
        return ['ok'=>true];
    });
}

function linkSubjectPart(Database $db, int $actor, array $input): array
{
    $from = positiveId($input['offering_id'] ?? null);
    $to = positiveId($input['target_offering_id'] ?? null);
    $expected = positiveId($input['expected_part_count'] ?? null);
    if ($from===$to) {
        fail('Elige dos asignaciones distintas.');
    }
    return $db->transaction(function () use ($db,$actor,$from,$to,$expected) {
        $sources = [];
        foreach ([min($from,$to),max($from,$to)] as $id) {
            $sources[$id] = subjectPartSource($db,$id);
        }
        $source = $sources[$from];
        $target = $sources[$to];
        if ($source['subject_id']!==$target['subject_id'] || $source['shift_id']!==$target['shift_id'] || $target['start_date']<=$source['end_date']) {
            fail('Las asignaciones deben corresponder a la misma materia y turno, en trimestres consecutivos sin superposición.');
        }
        if ($target['series_id']) {
            fail('La asignación de destino ya pertenece a una materia por partes.',409);
        }
        $series = $source['series_id'] ? $db->first('SELECT * FROM subject_series WHERE id=? FOR UPDATE',[$source['series_id']]) : null;
        if (($series['part_count'] ?? 1)!==$expected) {
            fail('Las partes cambiaron. Reabre el formulario antes de vincular.',409);
        }
        $rows = $db->rows('SELECT student_id,offering_id FROM enrollments WHERE offering_id IN (?,?) ORDER BY id FOR UPDATE',[$from,$to]);
        $groups = [$from=>[],$to=>[]];
        foreach ($rows as $row) {
            $groups[$row['offering_id']][] = $row['student_id'];
        }
        if ($groups[$from] && $groups[$to] && !array_intersect($groups[$from],$groups[$to])) {
            fail('Los grupos no comparten estudiantes. Revisa que sean el mismo grupo.');
        }
        [$seriesId,$number] = nextSubjectPart($db,$source,$series);
        $db->run('UPDATE offerings SET series_id=?,part_number=? WHERE id=?',[$seriesId,$number,$to]);
        $db->audit($actor,'Asignación existente vinculada como continuación',"Serie $seriesId · parte $number · asignaciones $from → $to");
        return ['ok'=>true,'series_id'=>$seriesId,'offering_id'=>$to,'part_number'=>$number,'students'=>count($groups[$to])];
    });
}
