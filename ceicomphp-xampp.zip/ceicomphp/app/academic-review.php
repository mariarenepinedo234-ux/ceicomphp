<?php

declare(strict_types=1);

function idsSql(array $ids): string
{
    return $ids ? implode(',',array_fill(0,count($ids),'?')) : 'NULL';
}

function hasNotes(array $row): bool
{
    return $row['grade'] !== null || $row['saber'] !== null || $row['hacer'] !== null || $row['ser'] !== null;
}

function academicSnapshot(Database $db, string $type, int $id, bool $lock = false): array
{
    $locking = $lock ? ' FOR UPDATE' : '';
    $offerings = [];
    if ($type === 'offering') {
        $record = $db->first(<<<'SQL'
SELECT o.*,s.career_id,s.level,s.name,
 COALESCE((SELECT n.name FROM career_names n WHERE n.career_id=c.id AND n.year_id=m.year_id),c.name) career,
 sh.name shift,m.name module,y.name AS `year`,u.name teacher,m.admission_year_id,m.year_id,m.start_date,m.end_date
FROM offerings o JOIN subjects s ON s.id=o.subject_id JOIN careers c ON c.id=s.career_id
JOIN shifts sh ON sh.id=o.shift_id JOIN modules m ON m.id=o.module_id
JOIN years y ON y.id=m.year_id JOIN users u ON u.id=o.teacher_id WHERE o.id=?
SQL . $locking,[$id]);
        $offerings = $record ? [$record] : [];
        $context = $record ? "{$record['career']} · {$record['level']}º AÑO · {$record['shift']} · {$record['module']} · GESTIÓN {$record['year']} · {$record['teacher']}" : '';
    } elseif ($type === 'module') {
        $record = $db->first('SELECT m.*,y.name year_name FROM modules m JOIN years y ON y.id=m.year_id WHERE m.id=?'.$locking,[$id]);
        $offerings = $db->rows('SELECT * FROM offerings WHERE module_id=? ORDER BY id'.$locking,[$id]);
        $context = $record ? "GESTIÓN {$record['year_name']} · {$record['start_date']} A {$record['end_date']}" : '';
    } elseif ($type === 'student') {
        $offerings = $db->rows('SELECT o.* FROM offerings o JOIN enrollments e ON e.offering_id=o.id WHERE e.student_id=? ORDER BY o.id'.$locking,[$id]);
        $record = $db->first("SELECT s.*,u.name,u.ci FROM students s JOIN users u ON u.id=s.user_id WHERE s.user_id=? AND u.role='student'".$locking,[$id]);
        $context = 'CI '.($record['ci'] ?? 'PENDIENTE')." · REGISTRO $id";
    } else {
        fail('Tipo de revisión inválido.');
    }
    if (!$record) {
        fail('Registro no encontrado.',404);
    }
    $offeringIds = array_column($offerings,'id');
    $offeringsSql = idsSql($offeringIds);
    $enrollments = $type === 'student'
        ? $db->rows('SELECT * FROM enrollments WHERE student_id=? ORDER BY id'.$locking,[$id])
        : $db->rows("SELECT * FROM enrollments WHERE offering_id IN ($offeringsSql) ORDER BY id".$locking,$offeringIds);
    $groups = $db->rows("SELECT * FROM academic_groups WHERE offering_id IN ($offeringsSql) ORDER BY id".$locking,$offeringIds);
    $groupIds = array_column($groups,'id');
    $groupsSql = idsSql($groupIds);
    $members = $type === 'student'
        ? $db->rows('SELECT * FROM academic_group_students WHERE student_id=? ORDER BY group_id'.$locking,[$id])
        : $db->rows("SELECT * FROM academic_group_students WHERE group_id IN ($groupsSql) ORDER BY group_id,student_id".$locking,$groupIds);
    $title = $type === 'offering' ? partRow($record + ['subject'=>$record['name']])['subject'] : upper($record['name']);
    $public = [
        'type'=>$type,'id'=>$id,'title'=>$title,'context'=>upper($context),
        'students'=>count(array_unique(array_column($enrollments,'student_id'))),'enrollments'=>count($enrollments),
        'notes'=>count(array_filter($enrollments,'hasNotes')),'offerings'=>count($offerings),'groups'=>count($groups),
        'revision'=>hash('sha256',json_encode([$record,$offerings,$enrollments,$groups,$members],JSON_THROW_ON_ERROR)),
    ];
    if ($type === 'offering' && $record['series_id']) {
        $public['deletion_blocked'] = 'Esta asignación pertenece a una materia por partes. Se conserva para mantener la secuencia y el promedio de sus estudiantes.';
    }
    return compact('record','offerings','enrollments','groups','members','public');
}

function confirmReview(array $input, array $state, string $phrase): void
{
    if (($input['confirm'] ?? null) !== $phrase) {
        fail("Escribe $phrase para confirmar.");
    }
    if (($input['revision'] ?? null) !== $state['public']['revision']) {
        fail('Los datos cambiaron desde la revisión. Cierra y abre de nuevo la confirmación.',409);
    }
}

function deleteAcademicRecord(Database $db, int $actor, string $type, array $input): array
{
    $id = positiveId($input[$type.'_id'] ?? null);
    $phrase = ['student'=>'ELIMINAR ESTUDIANTE','offering'=>'ELIMINAR ASIGNACION','module'=>'ELIMINAR TRIMESTRE'][$type];
    return $db->transaction(function () use ($db,$actor,$type,$input,$id,$phrase) {
        $state = academicSnapshot($db,$type,$id,true);
        if ($state['public']['deletion_blocked'] ?? false) {
            fail($state['public']['deletion_blocked'],409);
        }
        confirmReview($input,$state,$phrase);
        if ($type === 'student') {
            $db->run('DELETE FROM academic_group_students WHERE student_id=?',[$id]);
            $db->run('DELETE FROM enrollments WHERE student_id=?',[$id]);
            $db->run('DELETE FROM sessions WHERE user_id=?',[$id]);
            $db->run('UPDATE audit SET actor_id=NULL WHERE actor_id=?',[$id]);
            $db->run('DELETE FROM students WHERE user_id=?',[$id]);
            $db->run('DELETE FROM users WHERE id=?',[$id]);
        } else {
            if (array_filter(array_column($state['offerings'],'series_id'))) {
                fail('Este trimestre contiene partes de una materia. Conserva sus asignaciones.',409);
            }
            $groupIds = array_column($state['groups'],'id');
            $groupsSql = idsSql($groupIds);
            $offeringIds = array_column($state['offerings'],'id');
            $offeringsSql = idsSql($offeringIds);
            $db->run("DELETE FROM academic_group_students WHERE group_id IN ($groupsSql)",$groupIds);
            $db->run("DELETE FROM academic_groups WHERE id IN ($groupsSql)",$groupIds);
            $db->run("DELETE FROM enrollments WHERE offering_id IN ($offeringsSql)",$offeringIds);
            $db->run("DELETE FROM offerings WHERE id IN ($offeringsSql)",$offeringIds);
            if ($type === 'module') {
                $db->run('DELETE FROM modules WHERE id=?',[$id]);
            }
        }
        $db->audit($actor,$phrase,$state['public']['title'].' · '.$state['public']['enrollments'].' inscripciones');
        return ['ok'=>true];
    });
}

function rosterReview(Database $db, int $id): array
{
    return $db->transaction(function () use ($db,$id) {
        $state = academicSnapshot($db,'offering',$id);
        $r = $state['record'];
        $enrolled = array_column($state['enrollments'],'student_id');
        $existing = idsSql($enrolled);
        $cohort = $state['groups'][0]['admission_year_id'] ?? null;
        $students = $db->rows("SELECT s.*,u.name,u.ci,y.name admission_year FROM students s
            JOIN users u ON u.id=s.user_id JOIN years y ON y.id=s.admission_year_id
            WHERE s.user_id IN ($existing) OR (s.career_id=? AND s.shift_id=? AND
            ((s.level=? AND (? IS NULL OR s.admission_year_id=?)) OR s.level>?))
            ORDER BY UPPER(u.name),s.user_id",[...$enrolled,$r['career_id'],$r['shift_id'],$r['level'],$cohort,$cohort,$r['level']]);
        $regular = 0;
        $eligible = [];
        foreach ($students as $row) {
            $retake = $row['level'] > $r['level'];
            if (in_array($row['user_id'],$enrolled,true) || $retake || calendarAcceptsAdmission($db,$r,$row['admission_year_id'])) {
                $eligible[] = formatAcademicRow($row + ['retake_candidate'=>$retake]);
                $regular += (int) ($row['career_id'] === $r['career_id'] && $row['shift_id'] === $r['shift_id'] && $row['level'] === $r['level']);
            }
        }
        $profiles = $db->rows('SELECT level,COUNT(*) count FROM students WHERE career_id=? AND shift_id=? GROUP BY level',[$r['career_id'],$r['shift_id']]);
        $levels = array_replace([1=>0,2=>0,3=>0],array_column($profiles,'count','level'));
        $review = $state['public'];
        $review['context'] = upper("{$r['career']} · {$r['level']}º AÑO · {$r['module']} · {$r['year']} · {$r['shift']}");
        return $review + [
            'scope'=>['career_id'=>$r['career_id'],'shift_id'=>$r['shift_id'],'career'=>upper($r['career']),
                'shift'=>upper($r['shift']),'level'=>$r['level'],'levels'=>$levels,'regular_eligible'=>$regular],
            'student_ids'=>$enrolled,'graded_student_ids'=>array_column(array_filter($state['enrollments'],'hasNotes'),'student_id'),
            'students'=>$eligible,
        ];
    });
}

function updateOfferingRoster(Database $db, int $actor, array $input): array
{
    $id = positiveId($input['offering_id'] ?? null);
    $raw = $input['student_ids'] ?? null;
    if (!is_array($raw) || count($raw)>1000) {
        fail('Selecciona hasta 1000 estudiantes registrados.');
    }
    $ids = array_map('positiveId',$raw);
    if (count($ids)!==count(array_unique($ids))) {
        fail('Hay estudiantes repetidos en la selección.');
    }
    return $db->transaction(function () use ($db,$actor,$id,$input,$ids) {
        $state = academicSnapshot($db,'offering',$id,true);
        if (($input['revision'] ?? null) !== $state['public']['revision']) {
            fail('La lista o sus notas cambiaron. Cierra y abre de nuevo Editar inscritos.',409);
        }
        $enrolled = array_column($state['enrollments'],'student_id');
        $removed = array_values(array_diff($enrolled,$ids));
        foreach ($state['enrollments'] as $row) {
            if (in_array($row['student_id'],$removed,true) && hasNotes($row) && ($input['confirm_grades'] ?? null)!=='RETIRAR CON NOTAS') {
                fail('Hay estudiantes desmarcados con notas o borradores.',409);
            }
        }
        $r = $state['record'];
        $added = array_values(array_diff($ids,$enrolled));
        $cohort = $state['groups'][0]['admission_year_id'] ?? null;
        foreach ($added as $studentId) {
            $s = $db->first('SELECT * FROM students WHERE user_id=? FOR UPDATE',[$studentId]);
            if (!$s || $s['career_id'] !== $r['career_id'] || $s['shift_id'] !== $r['shift_id'] || $s['level'] < $r['level']
                || ($s['level'] > $r['level'] && !acceptsTrue($input['allow_retake'] ?? null))
                || ($s['level'] === $r['level'] && (($cohort !== null && $s['admission_year_id'] !== $cohort) || !calendarAcceptsAdmission($db,$r,$s['admission_year_id'])))) {
                fail('La selección contiene estudiantes de otra carrera, año, ingreso o turno.');
            }
            $db->run('INSERT INTO enrollments(student_id,offering_id,is_retake) VALUES (?,?,?)',[$studentId,$id,$s['level'] > $r['level']]);
        }
        $removedSql = idsSql($removed);
        $db->run("DELETE FROM enrollments WHERE offering_id=? AND student_id IN ($removedSql)",[$id,...$removed]);
        foreach ($state['groups'] as $group) {
            $db->run('DELETE FROM academic_group_students WHERE group_id=?',[$group['id']]);
            foreach ($ids as $studentId) {
                $db->run('INSERT INTO academic_group_students(group_id,student_id) VALUES (?,?)',[$group['id'],$studentId]);
            }
        }
        $db->audit($actor,'Lista de inscritos actualizada',"Asignación $id: ".count($added).' agregados, '.count($removed).' retirados.');
        return ['ok'=>true,'added'=>count($added),'removed'=>count($removed)];
    });
}
