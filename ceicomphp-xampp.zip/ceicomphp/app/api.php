<?php

declare(strict_types=1);

require_once __DIR__ . '/support.php';
require_once __DIR__ . '/academic-data.php';
require_once __DIR__ . '/academic-actions.php';
require_once __DIR__ . '/academic-review.php';
require_once __DIR__ . '/subject-parts.php';
require_once __DIR__ . '/career-management.php';
require_once __DIR__ . '/catalog.php';
require_once __DIR__ . '/reports.php';
require_once __DIR__ . '/study-plans.php';
require_once __DIR__ . '/backups.php';

date_default_timezone_set('UTC');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');

try {
    $configFile = getenv('CEICOM_CONFIG') ?: __DIR__ . '/config.local.php';
    if (!is_file($configFile)) {
        fail('Falta configurar la conexión MySQL en config.local.php.', 503);
    }
    $config = require $configFile;
    $method = $_SERVER['REQUEST_METHOD'];
    $path = $_SERVER['CEICOM_ROUTE'] ?? parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    if (!in_array($method, ['GET','POST'], true)) {
        fail('Método no permitido.', 405);
    }
    if ($path === '/api/config' && $method === 'GET') {
        jsonResponse(['demo' => false]);
    }

    $body = [];
    if ($method === 'POST') {
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        $scheme = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http';
        if ($origin !== '' && $origin !== $scheme . '://' . $_SERVER['HTTP_HOST']) {
            fail('Origen no permitido.', 403);
        }
        if ($path !== '/api/study-plans/upload') {
            $raw = file_get_contents('php://input', false, null, 0, 3145729);
            if (strlen($raw) > 3145728) {
                fail('Solicitud demasiado grande.', 413);
            }
            $body = json_decode($raw ?: '{}', true);
            if (!is_array($body) || !str_starts_with(ltrim($raw ?: '{}'), '{')) {
                fail('JSON inválido.');
            }
        }
    }

    $db = Database::connect($config['mysql']);
    $now = (int) floor(microtime(true) * 1000);
    $token = $_COOKIE['ceicom_session'] ?? '';
    $tokenHash = is_string($token) && preg_match('/^[0-9a-f]{64}$/D', $token) ? hash('sha256', $token) : '';
    if ($path === '/api/login' && $method === 'POST') {
        $ci = required($body['ci'] ?? null, 'Usuario');
        $password = required($body['password'] ?? null, 'Contraseña');
        $address = hash('sha256', $_SERVER['REMOTE_ADDR'] ?? '');
        $db->run('DELETE FROM login_attempts WHERE expires<=?', [$now]);
        $result = $db->transaction(function () use ($db, $ci, $password, $address, $now) {
            $db->run('INSERT INTO login_attempts(address,attempts,expires) VALUES (?,0,?) ON DUPLICATE KEY UPDATE address=VALUES(address)', [$address,$now + 900000]);
            $limit = $db->first('SELECT attempts FROM login_attempts WHERE address=? FOR UPDATE', [$address]);
            if ($limit && $limit['attempts'] >= 15) {
                fail('Demasiados intentos. Intenta en 15 minutos.', 429);
            }
            $user = $db->first('SELECT * FROM users WHERE ci=? FOR UPDATE', [$ci]);
            if (!$user || !verifyCeicomPassword($password, $user['password'])) {
                $db->run('INSERT INTO login_attempts(address,attempts,expires) VALUES (?,1,?) ON DUPLICATE KEY UPDATE attempts=attempts+1', [$address,$now + 900000]);
                return null;
            }
            $db->run('UPDATE login_attempts SET attempts=0,expires=? WHERE address=?', [$now + 900000,$address]);
            $token = bin2hex(random_bytes(32));
            $db->run('DELETE FROM sessions WHERE expires<=?', [$now]);
            $db->run('INSERT INTO sessions(token,user_id,expires) VALUES (?,?,?)', [hash('sha256',$token),$user['id'],$now + 28800000]);
            return [$token, $user];
        });
        if ($result === null) {
            fail('Usuario o contraseña incorrectos.', 401);
        }
        sessionCookie($result[0], time() + 28800);
        jsonResponse(publicUser($result[1]));
    }

    $user = $tokenHash === '' ? null : $db->first(
        'SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires>? AND u.ci IS NOT NULL AND u.password IS NOT NULL',
        [$tokenHash,$now]
    );
    if (!$user) {
        fail('Inicia sesión para continuar.', 401);
    }
    if ($path === '/api/me' && $method === 'GET') {
        jsonResponse(publicUser($user));
    }
    if ($path === '/api/logout' && $method === 'POST') {
        $db->run('DELETE FROM sessions WHERE token=?', [$tokenHash]);
        sessionCookie('', time() - 3600);
        jsonResponse(['ok' => true]);
    }
    if ($path === '/api/password' && $method === 'POST') {
        $current = required($body['current'] ?? null, 'Contraseña actual');
        $password = required($body['password'] ?? null, 'Contraseña nueva');
        if (mb_strlen($password) < 8 || $password === $current || $password === $user['ci']) {
            fail('Usa al menos 8 caracteres y una contraseña distinta del CI y la anterior.');
        }
        $db->transaction(function () use ($db,$user,$current,$password,$tokenHash) {
            $fresh = $db->first('SELECT password FROM users WHERE id=? FOR UPDATE', [$user['id']]);
            if (!$fresh || !verifyCeicomPassword($current, $fresh['password'])) {
                fail('La contraseña actual es incorrecta.');
            }
            $db->run('UPDATE users SET password=?,must_change=0 WHERE id=?', [hashCeicomPassword($password),$user['id']]);
            $db->run('DELETE FROM sessions WHERE user_id=? AND token<>?', [$user['id'],$tokenHash]);
            $db->audit($user['id'], 'Contraseña actualizada', $user['name']);
        });
        jsonResponse(['ok' => true]);
    }
    if ($user['must_change']) {
        fail('Cambia tu contraseña inicial para continuar.', 403);
    }
    if ($path === '/api/academic-history' && $method === 'GET') {
        jsonResponse(academicHistoryRecords($db, $user));
    }
    if ($path === '/api/data' && $method === 'GET') {
        jsonResponse(academicData($db, $user));
    }
    if ($path === '/api/grades' && $method === 'POST') {
        saveGrades($db, $user, $body);
        jsonResponse(['ok' => true]);
    }
    if ($method === 'GET' && preg_match('~^/api/reports/([1-9][0-9]*)$~D', $path, $match)) {
        sendReport($db, $user, positiveId($match[1]));
    }
    if ($path === '/api/study-plans' || str_starts_with($path,'/api/study-plans/')) {
        studyPlans($db,$user,$path,$method);
    }
    if ($path === '/api/backups' || str_starts_with($path,'/api/backups/')) {
        handleBackups($db,$user,$config,$path,$method);
    }
    if ($user['role'] !== 'admin') {
        fail('Acceso restringido.',403);
    }
    if ($method === 'GET') {
        if ($path === '/api/career-review') {
            $id = positiveId($_GET['career_id'] ?? null);
            jsonResponse($db->transaction(fn() => careerSnapshot($db,$id)['public']));
        }
        if ($path === '/api/pending-group-review') {
            $id = positiveId($_GET['group_id'] ?? null);
            jsonResponse($db->transaction(fn() => pendingGroupReview($db,$id)));
        }
        if ($path === '/api/academic-impact') {
            $type = required($_GET['type'] ?? null,'Tipo');
            $id = positiveId($_GET['id'] ?? null);
            jsonResponse($db->transaction(fn() => academicSnapshot($db,$type,$id)['public']));
        }
        if ($path === '/api/offering-roster') {
            jsonResponse(rosterReview($db,positiveId($_GET['offering_id'] ?? null)));
        }
    }
    if ($method === 'POST') {
        $result = adminAction($db, $user['id'], $path, $body);
        if ($result !== null) {
            jsonResponse($result);
        }
    }
    fail('Ruta no encontrada.', 404);
} catch (HttpError $error) {
    jsonResponse(['error' => $error->getMessage()], $error->getCode());
} catch (PDOException $error) {
    if (in_array($error->errorInfo[1] ?? null, [1062,1451,1452,3819,4025], true)) {
        jsonResponse(['error' => 'La operación no es válida. Revisa las relaciones y los datos seleccionados.'], 409);
    }
    error_log('Ceicom PDO: SQLSTATE ' . $error->getCode());
    jsonResponse(['error' => 'Ocurrió un error interno.'], 500);
} catch (Throwable $error) {
    error_log('Ceicom PHP: ' . get_class($error));
    jsonResponse(['error' => 'Ocurrió un error interno.'], 500);
}
